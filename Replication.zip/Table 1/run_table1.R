## "Inference on Conditional Quantile Processes in Partially Linear Models with Applications to the Impact of Unemployment Benefits" 
## by Zhongjun Qu, Jungmo Yoon, and Pierre Perron
## August 2021
## This script runs the simulation exercise reported in Table 1 of the paper

rm(list=ls())
require(quantreg)

depa <- function(xx,loc=0,scale=1){
# Epanechnikov kernel
	nx=(xx-loc)/scale
	return((scale^{-1})*(3/4)*(1-nx^2)*(abs(nx)<1))
}

n = 100000		# sample size
tlevel = c(0.1,0.5,0.9)		# quantile index
L = 500			# number of simualton repetitions

B = array(0,c(L,4,length(tlevel)))
B0 = array(0,c(2,length(tlevel)))

for(j in 1:L){
x = runif(n,min=-10,max=10)	# running variable
p = 0.5
w = rbinom(n,1,prob=p)		# covariate
x0 = 0
d = (x >= x0)
z = x-x0					# centered running variable

# generate dependent variable
rr = runif(n)
y = (5*(rr^2))*d + 8*(d*w) + qnorm(rr,sd=2.5)

hh = 10		# bandwidth
wk = depa(z/hh)		# weights
ind = abs(z) < hh

# Estimation

# E1: without covariate w
b1 <- rq(y~d+z+I(d*z),w=wk,tau=tlevel)	
B[j,1,] <- b1$coef[2,]

# E2: use covariate w but its coefficients are forced to be equal across the cutoff
#b2 <- rq(y~d+w+z+I(z*d)+I(z*w),w=wk,tau=tlevel)	# equality constraint imposed on z
b2 <- rq(y~d+w+z+I(z*d),w=wk,tau=tlevel)	# equality constraints imposed on (z, z*w)
B[j,2,] <- b2$coef[2,]

# E3: estimate heterogeneous effects with respect to covariate w
b3 <- rq(y~d+w+I(d*w)+z+I(z*d)+I(z*w)+I(z*d*w),w=wk,tau=tlevel)
B[j,3,] <- b3$coef[2,]
B[j,4,] <- b3$coef[2,] + b3$coef[4,]
print("the number of interation is "); print(j)
} # end of the loop

trueQ = rbind((5*(tlevel^2)),(8+5*(tlevel^2)))
B0 = trueQ

save(B,B0,tlevel,n,L,hh,file=paste("simul","_Aug18","_2021",".rda",sep=""))

# summary statistics
t(apply(B,c(2,3),mean))
t(apply(B,c(2,3),sd))

# make table
run.table = 0
if(run.table==1){
	
# make Table 1
ta0 <- NULL
for(j in 1:4){
	ta1 <- NULL
	for(k in 1:3){
		ta1 <- c(ta1,c(mean(B[,j,k]),sd(B[,j,k])))
	}
	ta0 <- cbind(ta0,ta1)
}
mar.Q <- c(1.294249,5.786618,10.108638)
tQ = rbind(mar.Q,B0)

tab <- cbind(rbind(tQ[,1],c(0,0,0),tQ[,2],c(0,0,0),tQ[,3],c(0,0,0)),ta0)
dimnames(tab) <- list(c("$\\tau=0.1$","","$\\tau=0.5$","","$\\tau=0.9$",""),c("Unconditional","$z=0$","$z=1$","E1","E2","E3 (z=0)","E3 (z=1)"))

cgroup = c("True Effects","Estimated Effects")
n.cgroup = c(3,4)

class(tab) <- "table"
require(quantreg)
caption <- " " 
latex(tab,file="table_effects_with_cov",
	cgroup=cgroup,n.cgroup=n.cgroup,
	dec = 2, caption= caption,rowlabel = " ") 

}
