## "Inference on Conditional Quantile Processes in Partially Linear Models with Applications to the Impact of Unemployment Benefits" 
## by Zhongjun Qu, Jungmo Yoon, and Pierre Perron
## August 2021
## This script replicates Figure 1 of the paper using 'Data_public.dta'
## The data is made available by Nekoei and Weber at http://doi.org/10.3886/E113058V1
## Also see 'run_application.R' for further information

rm(list=ls())
require(quantreg)
require("readstata13")
# read data
D <- read.dta13("Data_public.dta")
# call functions
source("qte_rdd_cov.R")

run.small = 0	# if 1, you can try this code on a randomly selected subset of data. This saves time. 
if(run.small==1){
	Ds <- D
	keep <- sample(1:nrow(Ds),20000,replace=F)
	D <- Ds[keep,]	
}

# Choose the outcome variable
k = 1	# outcome variable, k=1,2,3. See descriptions below
tlevels = 2:18/20	# quantile levels for QTE

# 1. Make variables
# 1.1. Define running variable and covariates
x = D$age
x0 = 40
d = (x>x0)
z = x - x0
dx = 1	# the number of the running variable (has to be '1')
w = NULL; mis.w = 0; dz = 0; z.eval = NULL # no covariate
#mis.c = is.na(D$industry) | is.na(D$work2_c) | is.na(D$work5_c)
mis.c = 0

# 1.2. Define the dependent variable
if(k==1){	# unemployment duration
	y = D$ned
	mis = is.na(D$ned) | mis.c | mis.w
}
if(k==2){	# wage changes
	y = D$wg_c
	mis = is.na(D$wg_c) | mis.c | mis.w
}
if(k==3){	# logarithm of pre-unemployment wage
	y = log(D$monthly_wage_n0)
	mis = is.na(D$monthly_wage_n0) | (D$monthly_wage_n0==0) | mis.c | mis.w
}
if(k %in% c(1,2)){ind <- (mis==0) & (D$ned < (365*2))}
if(k %in% c(3)){ind <- (mis==0) & (D$wv==1) & (D$ned < (365*2))}

ya = y[ind==1]; xa = x[ind==1]; da = d[ind==1]
if(is.vector(w)==1){wp = w[ind==1 & d==1]; wm = w[ind==1 & d==0]; wa = w[ind==1]}
if(is.vector(w)==0){wp = w[(ind==1 & d==1),]; wm = w[(ind==1 & d==0),]; wa = w[ind==1,]}

# 2. Bandwidth selection
# Careful! running the CV bandwidth with the full sample can take a long time

run.bandwidth = 0	# if 1, estimate the bandwidth, if 0, use the CV bandwidth as in Table 2 of the paper

# specifiy options for bandwidth calculations
	cv = 1		# if 1, esitmate cv bandwidth, cv=0, then calculate the optimal bandwidth only
	case = 1	# for discrete covariate
	p.order = 1 # order of the local polynomials in CV bandwidth
	pm.each = 0	# if 1, calculate bandwidth separately for each side of x0
	bdy.for = 1	# if 0 use interior cv formula, 1 use boundary cv formula
	val = 5:10	# candidiate values for the cv bandwidth

if(run.bandwidth==1){
	bn <- nrq.bandwidth.het(ya,cbind(xa,wa),da,dx,dz,x0,z0=z.eval,cv,pm.each,val=val,p.order=p.order,bdy=bdy.for,case)
	hm = bn$cv
}
if(run.bandwidth==0){ # use the CV bandwidth in Table 2 of the paper
	hh.cand = c(10,10,7)
	hm = hh.cand[k]
	bn <- NULL
}
# 3. QTE and Uniform Bands

# 3.1. QTE estiamtion
aa <- nrq.het(ya,cbind(xa,wa),da,dx,dz,x0,z0=z.eval,tau=tlevels,h.med=hm,opt=1,case)

# 3.2. Uniform bands
ba <- nrq.band.het(ya,cbind(xa,wa),da,dx,dz,x0,z0=z.eval,tau=tlevels,h.med=hm,alpha=0.9,opt=1,case)

# 4. Read and save outcomes

# QTE and conditional quantiles at each side of the cutoff
aa$qte
aa$Qm.est
aa$Qp.est

# Bias corrected QTE and the uniform confidence bands (conventional & robust bands)
ba$qte.cor
ba$uband
ba$uband.robust

save(bn,aa,ba,tlevels,cv,p.order,pm.each,bdy.for,val,file=paste("rep_app","_Aug",20,"_2021","_no_cov","_k",k,".rda",sep=""))
