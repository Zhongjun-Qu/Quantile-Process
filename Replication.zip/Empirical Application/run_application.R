## "Inference on Conditional Quantile Processes in Partially Linear Models with Applications to the Impact of Unemployment Benefits" 
## by Zhongjun Qu, Jungmo Yoon, and Pierre Perron
## August 2021
## This script replicates the empirical application in the paper
## Data is generously shared by Arash Nekoei and Andrea Weber

rm(list=ls())
require(quantreg)
# read data
D <- read.csv("data_rdd_cov.csv")
# call functions
source("qte_rdd_cov.R")

run.small = 0	# if 1, you can try this code on a randomly selected subset of data. This saves time. 
if(run.small==1){
	Ds <- D
	keep <- sample(1:nrow(Ds),20000,replace=F)
	D <- Ds[keep,]	
}

# Choose the model and the outcome variable
m = 3	# model, m=0,1,2,3,7,8,11,12,13. See descriptions below
k = 2	# outcome variable, k=1,2,3. See descriptions below

tlevels = 2:18/20	# quantile levels for QTE

# 1. Make variables
# 1.1. Define running variable and covariates
if(m==0){w = NULL; mis.w = 0; dz = 0; z.eval = NULL} # no covariate
if(m==1){dz=1; z.eval = c(0,1); w = D$female; mis.w <- rep(0,length(w))} # groups by gender
if(m==2){dz=1; z.eval = c(0,1); w = ifelse(D$bluecollar=="White Collar",1,0); mis.w <- rep(0,length(w))} # groups by occupation
if(m==3){	# groups by occupation & gender
	dz=3; z.eval = rbind(c(0,0,0),c(1,0,0),c(0,1,0),c(0,0,1))
	w1 = ifelse((D$female==1 & D$bluecollar=="Blue Collar"),1,0)
	w2 = ifelse((D$female==0 & D$bluecollar=="White Collar"),1,0)
	w3 = ifelse((D$female==1 & D$bluecollar=="White Collar"),1,0)
	w = cbind(w1,w2,w3)
	mis.w <- rep(0,nrow(w))
	}
if(m==7){	# by previous wage
	dz = 1; z.eval = c(0.1,0.5,0.75,0.9)
	w = D$wage0_pc/100
	mis.w = ifelse((D$wage0_pc==101),1,0)
}
if(m==8){	# by education
	dz=1; z.eval = c(0,1)
	w = ifelse((D$education=="college"),1,0)
	mis.w = ifelse(D$education=="unknown",1,0)
}
if(m==11){ # by work experience
	dz = 1; z.eval = c(0.1,0.5,0.7,0.9)
	w = D$work2_c/10
	mis.w = ifelse((is.na(D$work2_c)==1),1,0)
}
if(m==12){ # by firm size
	dz = 1; z.eval = c(0.1,0.5,0.7,0.9)
	w = D$firmsize_c_m/10
	mis.w = ifelse((D$firmsize_c_m==11),1,0)
}
if(m==13){ # by tenure
	dz = 1; z.eval = c(0.1,0.5,0.7,0.9)
	w = D$tenure_c/10
	mis.w = ifelse((D$tenure_c==11),1,0)
}
x = D$age
x0 = 40
d = (x>x0)
z = x - x0
dx = 1	# the number of the running variable (has to be '1')
mis.c = is.na(D$industry) | is.na(D$work2_c) | is.na(D$work5_c)

# 1.2. Define the dependent variable
if(k==1){	# unemployment duration
	y = D$ned
	mis = is.na(D$ned) | mis.c | mis.w
}
if(k==2){	# wage changes
	y = D$wg_c
	mis = is.na(D$wg_c) | mis.c | mis.w
}
if(k==3){	# logarithm of pre-unemployment wage
	y = log(D$monthly_wage_n0)
	mis = is.na(D$monthly_wage_n0) | (D$monthly_wage_n0==0) | mis.c | mis.w
}
if(k %in% c(1,2)){ind <- (mis==0) & (D$ned < (365*2))}
if(k %in% c(3)){ind <- (mis==0) & (D$wv==1) & (D$ned < (365*2))}

ya = y[ind==1]; xa = x[ind==1]; da = d[ind==1]
if(is.vector(w)==1){wp = w[ind==1 & d==1]; wm = w[ind==1 & d==0]; wa = w[ind==1]}
if(is.vector(w)==0){wp = w[(ind==1 & d==1),]; wm = w[(ind==1 & d==0),]; wa = w[ind==1,]}
if(m==3 & k==1){ # to avoid singular matrix problem when m=3, k=1
	ya1 <- dither(ya,type = "symmetric", value = 1); ya  <- ya1
}

# 2. Bandwidth selection
# Careful! running the CV bandwidth with the full sample can take a long time

run.bandwidth = 0	# if 1, estimate the bandwidth, if 0, use the CV bandwidth as in Table 2 of the paper

# specifiy options for bandwidth calculations
	cv = 1		# if 1, esitmate cv bandwidth, cv=0, then calculate the optimal bandwidth only
	if(m %in% c(0,1,2,3,8)){case=1}	# discrete covariate
	if(m %in% c(7,11,12,13)){case=2}	# continuous covariate
	p.order = 1 # order of the local polynomials in CV bandwidth
	pm.each = 0	# if 1, calculate bandwidth separately for each side of x0
	bdy.for = 1	# if 0 use interior cv formula, 1 use boundary cv formula
	val = 5:10	# candidiate values for the cv bandwidth

if(run.bandwidth==1){
	bn <- nrq.bandwidth.het(ya,cbind(xa,wa),da,dx,dz,x0,z0=z.eval,cv,pm.each,val=val,p.order=p.order,bdy=bdy.for,case)
	hm = bn$cv
}
if(run.bandwidth==0){ # use the CV bandwidth in Table 7
	if(m==0){hh.cand = c(10,10,7)}
	if(m==1){hh.cand = c(7,10,6)}
	if(m==2){hh.cand = c(10,10,6)}
	if(m==3){hh.cand = c(5,10,6)}
	if(m==7){hh.cand = c(10,10,7)}
	if(m==8){hh.cand = c(10,9,6)}
	if(m==11){hh.cand = c(10,10,6)}
	if(m==12){hh.cand = c(10,10,7)}
	if(m==13){hh.cand = c(10,10,7)}
	hm = hh.cand[k]
	bn <- NULL
}
# 3. QTE and Uniform Bands

# 3.1. QTE estiamtion
aa <- nrq.het(ya,cbind(xa,wa),da,dx,dz,x0,z0=z.eval,tau=tlevels,h.med=hm,opt=1,case)

# 3.2. Uniform bands
ba <- nrq.band.het(ya,cbind(xa,wa),da,dx,dz,x0,z0=z.eval,tau=tlevels,h.med=hm,alpha=0.9,opt=1,case)

# 4. Read and save outcomes

# QTE and conditional quantiles at each side of the cutoff
aa$qte
aa$Qm.est
aa$Qp.est

# Bias corrected QTE and the uniform confidence bands (conventional & robust bands)
ba$qte.cor
ba$uband
ba$uband.robust

save(bn,aa,ba,tlevels,cv,p.order,pm.each,bdy.for,val,file=paste("rep_app","_Aug",18,"_2021","_m",m,"_k",k,".rda",sep=""))
