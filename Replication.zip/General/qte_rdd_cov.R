## "Inference on Conditional Quantile Processes in Partially Linear Models with Applications to the Impact of Unemployment Benefits" 
## by Zhongjun Qu, Jungmo Yoon, and Pierre Perron
## August 2021
## Main functions for (i) estimation, (ii) confidence band, (iii) bandwidth selection for QTE (and conditional quantile process)

source("qte_rdd_cov_fn.R")
require(quantreg)

## 1. Main functions for Simulation exercises:
## estiamtion, confidence bands, bandwidths, test

# 1.1. function for partially linear quantile regression 
nrq <- function(y,x,dx,dz,x0,z0,tau,h.med,h.med2,rdd=1,step1=1,se=0){
	# nrq() estimates conditional quantiles for the partially linear model
	tt  <- sort(unique(c(tau,0.5)))	# qualtile levels to estimate
	hh  <- h.med*rep(1,length(tt))	# bandwidth for Step 1 of the global model 
	hh2 <- h.med2*((2*tt*(1-tt)/(pi*dnorm(qnorm(tt))^{2}))^{1/(4+dx)})	# bandwidth for estimation and inference (estimate conditional quantiles and biases)
	# estimate conditional quantiles
	if(rdd==0){
		if(step1==1){sa <- est.s1(y,x,dx,dz,x0,z0,tt,hh,hh2,se)}
		if(step1==0){sa <- est.s0(y,x,dx,dz,x0,z0,tt,hh,hh2,se)}
	}
	if(rdd==1){
		d = (x[,1] >= x0)
		xm = x[d==0,]; xp = x[d==1,]; ym = y[d==0]; yp = y[d==1]
		if(step1==1){
			sm <- est.s1(ym,xm,dx,dz,x0,z0,tt,hh,hh2,get.se=se)
			sp <- est.s1(yp,xp,dx,dz,x0,z0,tt,hh,hh2,get.se=se)
		}
		if(step1==0){
			sm <- est.s0(ym,xm,dx,dz,x0,z0,tt,hh,hh2,get.se=se)
			sp <- est.s0(yp,xp,dx,dz,x0,z0,tt,hh,hh2,get.se=se)
		}
	}
	# save outcomes
	if(rdd==0){
		g.hat = sa$ghat
		beta.hat = sa$beta.hat
		bias.hat = sa$bias
		B.hat = sa$B.hat
		Q.hat = sa$Qhat
		Q.hat.cor = Q.hat - bias.hat		
	}
	if(rdd==1){
		g.hat = sp$ghat - sm$ghat
		beta.hat = rbind(sp$beta.hat,sm$beta.hat)
		bias.hat = sp$bias - sm$bias
		B.hat = cbind(sp$B.hat,sm$B.hat)
		Q.hat = sp$Qhat - sm$Qhat
		Q.hat.cor = Q.hat - bias.hat		
	}
	if(se==1 & rdd==0){g.se = sa$g.se; ga.se = sa$ga.se}
	if(se==0 | rdd==1){g.se = NULL; ga.se = NULL}
	if(rdd==1){Q.hat.p = sp$Qhat; Q.hat.m = sm$Qhat}
	if(rdd==0){Q.hat.p = NULL; Q.hat.m = NULL}
	return(list(x0 = x0, z0 = z0, Q.est = Q.hat, Q.est.p = Q.hat.p, Q.est.m = Q.hat.m, beta.est = beta.hat, g.est = g.hat, bias.est = bias.hat, Q.est.cor = Q.hat.cor, B.est = B.hat, g.se = g.se, ga.se = ga.se))
}

# 1.2. uniform confidence bands
nrq.band <- function(y,x,dx,dz,x0,z0,tau,h.med,h.med2,alpha=0.9,n.sim=1000,rdd=1,step1=1,res=0){
	# nrq.band() estimates conditional quantiles & obtain uniform confidence bands
	# the default is the uniform band based on asymptotic linear approximation (Wald band)
	# if res==1, calculate the uniform band based on resampling (Score band)
	tt <- sort(unique(c(tau,0.5)))	# determine qualtile levels to estimate
	tt.ext <- c(0.25,0.5)*tt[1]		# extend the quantile range for conditional density estimation
	tt.exp <- sort(c(tt.ext,tt,(1-tt.ext)))
	ind <- tt.exp %in% tt
	hh  <- h.med*rep(1,length(tt.exp))	# bandwidth for step 1
	hh2 <- h.med2*((2*tt.exp*(1-tt.exp)/(pi*dnorm(qnorm(tt.exp))^{2}))^{1/(4+dx)})	# bandwidth for estimation and inference (estimate conditional quantiles and bias terms)

	if(rdd==0){
		# 1. estimating conditional quantiles
		sa <- nrq(y,x,dx,dz,x0,z0,tau=tt.exp,h.med,h.med2,rdd=0,step1,se=res)
		delta <- bandwidth.rq(tt,length(y),hs=F)
		# 2. uniform confidence bands		
		fhat <- condf.est(x,x0,g.est=sa$g.est,dx,dz,taus=tt,taul=tt.exp,h.tau=hh2[ind],beta=sa$beta.est,delta=delta)$ff
		if(step1==1){
			wald <- band.asy(y,x,dx,dz,x0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],beta=sa$beta.est[,ind],Qy=sa$Q.est[ind],fqx=fhat,bias=sa$bias.est[ind],alpha=alpha,n.sim)
		}
		if(step1==0){
			wald <- band.asy.big(y,x,dx,dz,x0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],Qy=sa$Q.est[ind],fqx=fhat,bias=sa$bias.est[ind],alpha=alpha,n.sim)
		}
	}
	if(rdd==1){
		# 1. estimating conditional quantiles
		d = (x[,1] >= x0)
		xm = x[d==0,]; xp = x[d==1,]; ym = y[d==0]; yp = y[d==1]
		delta = bandwidth.rq(tt,length(y),hs=F)
		sm = nrq(ym,xm,dx,dz,x0,z0,tau=tt.exp,h.med,h.med2,rdd=0,step1,se=res)
		sp = nrq(yp,xp,dx,dz,x0,z0,tau=tt.exp,h.med,h.med2,rdd=0,step1,se=res)
		# 2. uniform confidence bands		
		fhat.m = condf.est(xm,x0,g.est=sm$g.est,dx,dz,taus=tt,taul=tt.exp,h.tau=hh2[ind],beta=sm$beta.est,delta=delta)$ff
		fhat.p = condf.est(xp,x0,g.est=sp$g.est,dx,dz,taus=tt,taul=tt.exp,h.tau=hh2[ind],beta=sp$beta.est,delta=delta)$ff
		if(step1==1){
			wald.m <- band.asy(ym,xm,dx,dz,x0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],beta=sm$beta.est[,ind],Qy=sm$Q.est[ind],fqx=fhat.m,bias=sm$bias.est[ind],alpha=alpha,n.sim)
			wald.p <- band.asy(yp,xp,dx,dz,x0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],beta=sp$beta.est[,ind],Qy=sp$Q.est[ind],fqx=fhat.p,bias=sp$bias.est[ind],alpha=alpha,n.sim)
		}
		if(step1==0){
			wald.m <- band.asy.big(ym,xm,dx,dz,x0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],Qy=sm$Q.est[ind],fqx=fhat.m,bias=sm$bias.est[ind],alpha=alpha,n.sim)
			wald.p <- band.asy.big(yp,xp,dx,dz,x0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],Qy=sp$Q.est[ind],fqx=fhat.p,bias=sp$bias.est[ind],alpha=alpha,n.sim)
		}
		wald <- make.band.rdd(length(y),Dc.p=wald.p$dc,Dc.m=wald.m$dc,Dr.p=wald.p$dr,Dr.m=wald.m$dr,dx,dz,taus=tt,hh=hh2[ind],Qy.p=sp$Q.est[ind],Qy.m=sm$Q.est[ind],bias.p=sp$bias.est[ind],bias.m=sm$bias.est[ind],alpha,type=1)
	}
	# Score band - optional 
	if(res==1 & rdd==0){
		if(step1==1){
			score <- try(band.res(y,x,dx,dz,x0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],beta=sa$beta.est[,ind],Qy=sa$Q.est[ind],ghat=sa$g.est[ind],bias=sa$bias.est[ind],bhat=sa$B.est[ind],gse=sa$g.se[ind],bse=sa$ga.se[ind],alpha=alpha,n.sim=(n.sim/2),con=5))
		}
		if(step1==0){
			score <- try(band.res.big(y,x,dx,dz,x0,z0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],Qy=sa$Q.est[ind],ghat=sa$Q.est[ind],bias=sa$bias.est[ind],bhat=sa$B.est[ind],gse=sa$g.se[ind],bse=sa$ga.se[ind],alpha=alpha,n.sim=(n.sim/2),con=3))
		}
		if("uband" %in% attr(score,"names")){res.sc = 1}
		else{res.sc = 0}
	}
	if(res==1 & rdd==1){
		if(step1==1){
			score.m <- try(band.res(ym,xm,dx,dz,x0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],beta=sm$beta.est[,ind],Qy=sm$Q.est[ind],ghat=sm$g.est[ind],bias=sm$bias.est[ind],bhat=sm$B.est[ind],gse=sm$g.se[ind],bse=sm$ga.se[ind],alpha=alpha,n.sim=(n.sim/2),con=5))
			score.p <- try(band.res(yp,xp,dx,dz,x0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],beta=sp$beta.est[,ind],Qy=sp$Q.est[ind],ghat=sp$g.est[ind],bias=sp$bias.est[ind],bhat=sp$B.est[ind],gse=sp$g.se[ind],bse=sp$ga.se[ind],alpha=alpha,n.sim=(n.sim/2),con=5))
		}
		if(step1==0){
			score.m <- try(band.res.big(ym,xm,dx,dz,x0,z0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],Qy=sm$Q.est[ind],ghat=sm$Q.est[ind],bias=sm$bias.est[ind],bhat=sm$B.est[ind],gse=sm$g.se[ind],bse=sm$ga.se[ind],alpha=alpha,n.sim=(n.sim/2),con=3))
			score.p <- try(band.res.big(yp,xp,dx,dz,x0,z0,taus=tt,h.tau=hh2[ind],h.tau2=hh2[ind],Qy=sp$Q.est[ind],ghat=sp$Q.est[ind],bias=sp$bias.est[ind],bhat=sp$B.est[ind],gse=sp$g.se[ind],bse=sp$ga.se[ind],alpha=alpha,n.sim=(n.sim/2),con=3))
		}
		if(("uband" %in% attr(score.p,"names")) & ("uband" %in% attr(score.m,"names"))){
		score <- make.band.rdd(length(y),Dc.p=score.p$dc,Dc.m=score.m$dc,Dr.p=score.p$dr,Dr.m=score.m$dr,dx,dz,taus=tt,hh=hh2[ind],Qy.p=sp$Q.est[ind],Qy.m=sm$Q.est[ind],bias.p=sp$bias.est[ind],bias.m=sm$bias.est[ind],alpha,type=2)
		res.sc = 1
		}
		else{res.sc = 0}
	}
	# collect outcomes
	if(rdd==0){
		Q.hat <- wald$est
		Q.hat.cor <- wald$est.adj
	}
	if(rdd==1){
		Q.hat <- wald$qte
		Q.hat.cor <- wald$qte.r
	}
	uband <- wald$uband
	uband.robust <- wald$uband.r
	if(res==1){uband.R <- score$uband; uband.robust.R <- score$uband.r}
	if(res==0){uband.R <- NULL; uband.robust.R <- NULL; res.sc <- NULL}
	return(list(x0 = x0, z0 = z0, Q.est = Q.hat, Q.est.cor = Q.hat.cor, uband = uband, uband.robust = uband.robust, uband.R = uband.R, uband.robust.R = uband.robust.R, res.sc = res.sc))		
}

# 1.3. bandwidth calculation
nrq.bandwidth <- function(y,x,dx,dz,x0,z0,rdd,step1=1,bdy=1,order=2,cv=0,hp=NULL){
	# nrq.bandwidth() obtains the CV and MSE optimal bandwidths
	# if cv=1, estimate the CV bandwidth and use it as a pilot bandwidth for the MSE optimal bandwidth. If cv=0, do not estimate CV bandwidth and use hp for the pilot bandwidth
	# step1=1 is for the global model, step1=0 is for the local model	
	# order=1 uses local linear regression for CV bandwidth, order=2 uses local quadratic regression
	# bdy=1 uses the boundary formula for the MSE optimal bandwidth, bdy=0 uses the interior formula
	delta <- bandwidth.rq(0.5,length(y),hs=F)
	tt <- 0.5 + c(-delta,0,delta)		# estimate Q(tau) at three tau's (for conditional density estimation)
	tt <- round(tt,2)
	if(rdd==0){
		if(cv==1){h.cv  <- bandwidth.cv(y,x,dx,dz,x0,order,opt=2)$h.cv}
		if(cv==0){h.cv  <- hp}
		sa <- nrq(y,x,dx,dz,x0,z0,tau=tt,h.med=h.cv,h.med2=h.cv,rdd=0,step1,se=0)
		g.hat <- sa$g.est
		beta.hat <- sa$beta.est
		h.opt <- bandwidth.opt(y,x,dx,dz,x0,Qy=g.hat,beta=beta.hat,band=h.cv,delta,bdy)$h.op
	}	
	if(rdd==1){
		d = (x[,1] >= x0)
		xm = x[d==0,]; xp = x[d==1,]; ym = y[d==0]; yp = y[d==1]
		if(cv==1){
			h.cv.m  <- bandwidth.cv(ym,xm,dx,dz,x0,order,opt=2)$h.cv
			h.cv.p  <- bandwidth.cv(yp,xp,dx,dz,x0,order,opt=2)$h.cv
		}
		if(cv==0){h.cv.m <- hp; h.cv.p <- hp}
		sm <- nrq(ym,xm,dx,dz,x0,z0,tau=tt,h.med=h.cv.m,h.med2=h.cv.m,rdd=0,step1,se=0)
		sp <- nrq(yp,xp,dx,dz,x0,z0,tau=tt,h.med=h.cv.p,h.med2=h.cv.p,rdd=0,step1,se=0)
		g.hat.m <- sm$g.est
		beta.hat.m <- sm$beta.est
		h.opt.m <- bandwidth.opt(ym,xm,dx,dz,x0,Qy=g.hat.m,beta=beta.hat.m,band=h.cv.m,delta,bdy)$h.op		
		g.hat.p <- sp$g.est
		beta.hat.p <- sp$beta.est
		h.opt.p <- bandwidth.opt(yp,xp,dx,dz,x0,Qy=g.hat.p,beta=beta.hat.p,band=h.cv.p,delta,bdy)$h.op
	}
	# impose a bound for the optimal bandwidth. This is embded for the CV bandwidth in bandwidth.cv().
	if(dx==1){bm = max(x[,1])-min(x[,1])}
	if(dx >1){bm = max(diff(range(x[,1])),diff(range(x[,2])))}
	if(rdd==0){h.opt <- max((0.25*bm),min(bm,h.opt))}
	if(rdd==1){
		h.opt.m <- max((0.25*bm),min(bm,h.opt.m))
		h.opt.p <- max((0.25*bm),min(bm,h.opt.p))		
	}	
	if(rdd==0){return(list(h.cv = h.cv, h.opt = h.opt))}
	if(rdd==1){return(list(h.cv.m = h.cv.m, h.cv.p = h.cv.p, h.opt.m = h.opt.m, h.opt.p = h.opt.p))}
}

#########################
## 2. Functions specialized for the RDD with covariates

nrq.het <- function(y,x,d,dx,dz,x0,z0=NULL,tau,h.med,opt=1,case=1){
	# nrq.het() estimates QTE for RDD with covariates
	# obtains QTE for each subgroup
	# use it only for RDD. Hence, set dx=1
	# opt=1 use quantile specific bandwidth, opt=0 uses the same bandwidth across quantiles
	# case=1 for dummy covariates, case=2 for continuous covariates
	if(dx!=1)
		stop("running variable should be univariate")
	x = as.matrix(x)
	z = x[,1] - x0
	if(case==1){dg = dz+1}	# number of groups by covariates
	if(case==2){dg = length(z0)}
	if(dz==0){w = NULL}
	if(dz >0){w = as.matrix(x[,-(1:dx)])}
	ym = y[d==0]; yp = y[d==1]; zm = z[d==0]; zp = z[d==1]; wm = w[d==0,]; wp = w[d==1,]
	# quantile levels and bandwidths
	tt <- sort(unique(c(tau,0.5)))	# qualtile levels to estimate
	hh  <- rep(h.med,length(tt)) 	# determine bandwidth values	
	hh2 <- h.med*((2*tt*(1-tt)/(pi*dnorm(qnorm(tt))^{2}))^{1/(4+dx)})
	# estimation
	bcoe.p <- array(0,c(length(tt),(dz+1))); bcoe.m <- bcoe.p
	for(i in 1:length(tt)){
		if(opt==0){kp = depa(zp/hh[i]); km = depa(zm/hh[i])}
		if(opt==1){kp = depa(zp/hh2[i]); km = depa(zm/hh2[i])}
		if(dz==0){m1 <- yp ~ zp; m2 <- ym ~ zm}
		if(dz>=1){m1 <- yp ~ zp + wp + I(zp*wp); m2 <- ym ~ zm + wm + I(zm*wm)}
			b1 <- try(rq(m1,method="fn",subset=(kp!=0),tau=tt[i],w=kp))
			b2 <- try(rq(m2,method="fn",subset=(km!=0),tau=tt[i],w=km))
		if(dz==0){bcoe.p[i,1] <- b1$coef[1]; bcoe.m[i,1] <- b2$coef[1]}
		if(dz>=1){
			bcoe.p[i,] <- b1$coef[c(1,(2+dx):(1+dx+dz))]
			bcoe.m[i,] <- b2$coef[c(1,(2+dx):(1+dx+dz))]			
		}
	}
	Qp = array(0,c(length(tt),dg)); Qm = Qp; Qd = Qp
	if(dz==0){
		Qp[,1] <- bcoe.p[,1]; Qm[,1] <- bcoe.m[,1]
		Qd[,1] <- Qp[,1] - Qm[,1]
	}
	if(dz==1){
		for(jj in 1:dg){
			Qp[,jj] <- bcoe.p[,1] + bcoe.p[,2]*z0[jj]
			Qm[,jj] <- bcoe.m[,1] + bcoe.m[,2]*z0[jj]
			Qd[,jj] <- Qp[,jj] - Qm[,jj]
		}
	}
	if(dz>=2){
		for(jj in 1:dg){
			for(i in 1:length(tt)){
				Qp[i,jj] <- bcoe.p[i,] %*% c(1,z0[jj,])
				Qm[i,jj] <- bcoe.m[i,] %*% c(1,z0[jj,])			
			}
			Qd[,jj] <- Qp[,jj] - Qm[,jj]
		}
	}
	return(list(qte = Qd, Qp.est = Qp, Qm.est = Qm, bcoe.p = bcoe.p, bcoe.m = bcoe.m))
}

nrq.band.het <- function(y,x,d,dx,dz,x0,z0=NULL,tau,h.med,alpha=0.9,opt=1,case=1){
	# QTE and the (alpha*100)% uniform confidence band
	x = as.matrix(x)
	n = length(y)
	if(dz==0){w = NULL}
	if(dz!=0){w = as.matrix(x[,(1+dx):(dx+dz)])}
	if(case==1){dg = dz+1}	# number of groups by covariates
	if(case==2){dg = length(z0)}
	n.sim = ifelse((n<50000),1000,500)	# number of simulation repetitions for the uniform bands
	# qualtile levels to estimate
	tt <- sort(unique(c(tau,0.5)))
	tt.ext <- c(0.25,0.5)*tt[1]	# for conditional density estimation
	tt.exp <- sort(c(tt.ext,tt,(1-tt.ext)))
	ind <- tt.exp %in% tt
	hh2 <- h.med*((2*tt.exp*(1-tt.exp)/(pi*dnorm(qnorm(tt.exp))^{2}))^{1/(4+dx)})
	# obtains QTE and uniform bands
	ab <- nrq.het(y,x,d,dx,dz,x0,z0,tau=tt.exp,h.med,opt,case)
	# Bias estimation
	delta = bandwidth.rq(tt,n,hs=F)
	fp <- condf.est.het(x,dx,dz,z0,Q=ab$Qp.est,bcoe=ab$bcoe.p,taus=tt,taul=tt.exp,delta,case)
	fm <- condf.est.het(x,dx,dz,z0,Q=ab$Qm.est,bcoe=ab$bcoe.m,taus=tt,taul=tt.exp,delta,case)
	bp <- bias.est.het(y[d==1],x[(d==1),],dx,dz,x0,z0,taus=tt,hh2[ind],hh2[ind],fx=fp$ff[(d==1),],se=0)
	bm <- bias.est.het(y[d==0],x[(d==0),],dx,dz,x0,z0,taus=tt,hh2[ind],hh2[ind],fx=fm$ff[(d==0),],se=0)
	# uniform bands
	sm <- nrq.sim(x,d,x0,z0,dx,dz,tt=tt,hh2[ind],hh2[ind],fxp=fp$ff,fxm=fm$ff,n.sim)
	wba <- make.band.het(n,Dc.p=sm$dcp,Dc.m=sm$dcm,Dr.p=sm$drp,Dr.m=sm$drm,dx,dz,taus=tt,hh2[ind],Qy.p=as.matrix(ab$Qp.est[ind,]),Qy.m=as.matrix(ab$Qm.est[ind,]),bias.p=bp$bias,bias.m=bm$bias,alpha,n.sim)
	return(list(qte = wba$qte, qte.cor = wba$qte.r, uband = wba$uband, uband.robust = wba$uband.r))
}

nrq.bandwidth.het <- function(y,x,d,dx,dz,x0,z0=NULL,cv,pm.each,val,p.order,bdy,case){
	# estimate the cross-validation (CV) and the MSE optimal (Opt) bandwidths
	# cv=1, then obtain the CV bandwidth, cv=0, only estimate the Opt bandwidth
	# pm.each=1, then calculates the CV bandwidth on each side of the cutoff
	# val is is vector of caididate values for the CV bandwidth
	# p.order = 1 (or 2), use the local linear (quadratic) regression
	# bdy=1, use the boundary CV bandwidth, bdy=0, use the interior CV bandwidth
	# case=1 for dummy covariates, case=2 for continuous covariates. This information is needed for the conditional density estiamtion
	n = length(y)
	if(dz==0){w = NULL}
	if(dz!=0){w = as.matrix(x[,(1+dx):(dx+dz)])}
	if(case==1){dg = dz+1}	# number of groups by covariates
	if(case==2){dg = length(z0)}
	n.sim = ifelse((n<50000),300,100)
	xl = 0.5 	# CV bandwidth use (xl*100)% of observations closest from x0 for evaluation points
	# CV bandwidth
	if(cv==1){
		if(pm.each==0){
			banda <- plm.cv.app(y=y, x=x[,1], z=w, dz, x0, val, xl, order=p.order, bdy)
		}
		if(pm.each==1){
			bandp <- plm.cv.app(y[d==1],x[(d==1),1],w[(d==1),],dz,x0, val, xl, order=p.order, bdy)
			bandm <- plm.cv.app(y[d==0],x[(d==0),1],w[(d==0),],dz,x0, val, xl, order=p.order, bdy)
		}
	}
	if(cv==0){banda = NULL}
	# Optimal bandwidth
	delta.m = bandwidth.rq(0.5,length(y[d==0]),hs=F)
	delta.p = bandwidth.rq(0.5,length(y[d==1]),hs=F)
	tt.m = 0.5 + c(-delta.m,0,delta.m); tt.m = round(tt.m,2)
	tt.p = 0.5 + c(-delta.p,0,delta.p); tt.p = round(tt.p,2)
	h.op.m <- array(0,c(length(val),dg)); h.op.p <- array(0,c(length(val),dg))
	for(j in 1:length(val)){
		hh = val[j]
		ab.p <- nrq.het(y,x,d,dx,dz,x0,z0,tau=tt.p,h.med=hh,opt=0,case)
		ab.m <- nrq.het(y,x,d,dx,dz,x0,z0,tau=tt.m,h.med=hh,opt=0,case)
		fp <- condf.est.het(x,dx,dz,z0,Q=ab.p$Qp.est,bcoe=ab.p$bcoe.p,taus=0.5,taul=tt.p,delta.p,case)
		fm <- condf.est.het(x,dx,dz,z0,Q=ab.m$Qm.est,bcoe=ab.m$bcoe.m,taus=0.5,taul=tt.m,delta.m,case)
		bp <- bias.est.het(y[d==1],x[(d==1),],dx,dz,x0,z0,taus=0.5,hh,hh,fx=as.matrix(fp$ff[(d==1)]),se=0)
		bm <- bias.est.het(y[d==0],x[(d==0),],dx,dz,x0,z0,taus=0.5,hh,hh,fx=as.matrix(fm$ff[(d==0)]),se=0)
		sim <- nrq.sim(x,d,x0,z0,dx,dz,tt=0.5,hh,hh,fxp=fp$ff,fxm=fm$ff,n.sim)
		sm <- as.matrix(sim$dcm); sp <- as.matrix(sim$dcp)
		if(dz==0){
			h.op.m[j,1] <- ((mean(sim$dcm^2)/(4*(bm$bhat^2)))^{1/5})*(n^{-1/5})
			h.op.p[j,1] <- ((mean(sim$dcp^2)/(4*(bp$bhat^2)))^{1/5})*(n^{-1/5})
		}
		if(dz>0){
			for(l in 1:dg){
				h.op.m[j,l] <- ((mean(sm[l,]^2)/(4*(bm$bhat[l]^2)))^{1/5})*(n^{-1/5})
				h.op.p[j,l] <- ((mean(sp[l,]^2)/(4*(bp$bhat[l]^2)))^{1/5})*(n^{-1/5}) 
			}
		}
	}
	# save bandwidth values
	bandwidth = NULL
	if(cv==1 & pm.each==0){bandwidth$cv = banda$h.cv}
	if(cv==1 & pm.each==1){bandwidth$cv = c(bandm$h.cv,bandp$h.cv)}
	# optimal bandwidth can be truncated by the max of 'val', the caldidate values
	h.op.m = pmin(h.op.m,max(val)); h.op.p = pmin(h.op.p,max(val))
	bandwidth$opt.m.list = cbind(val,h.op.m); bandwidth$opt.p.list = cbind(val,h.op.p)
	colnames(bandwidth$opt.m.list) <- c("pilot bandwidths","Opt_m",rep("",dg-1))
	colnames(bandwidth$opt.p.list) <- c("pilot bandwidths","Opt_p",rep("",dg-1))
	if(cv==1 & pm.each==0){bandwidth$opt.m = h.op.m[(val==banda$h.cv)]; bandwidth$opt.p = h.op.p[(val==banda$h.cv)]}
	if(cv==1 & pm.each==1){bandwidth$opt.m = h.op.m[(val==bandm$h.cv)]; bandwidth$opt.p = h.op.p[(val==bandp$h.cv)]}
	return(bandwidth)
}


