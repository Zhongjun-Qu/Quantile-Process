## "Inference on Conditional Quantile Processes in Partially Linear Models with Applications to the Impact of Unemployment Benefits" 
## by Zhongjun Qu, Jungmo Yoon, and Pierre Perron
## August 2021
## Auxiliary functions

## 1. Functions for simulation

# 1.1. Point estimation: First and second step estimation. 

# estimation for a global model (with step 1)
est.s1 <- function(y,x,dx,dz,x0,z0,tau,hh,hh2,get.se){
	# Step 1
	Be <- array(0,c(length(y),length(tau),dz))
	for(j in 1:length(y)){
		Be[j,,] <- qrp.fir(y[-j],as.matrix(x[-j,]),dx,dz,x0=x[j,1:dx],taus=tau,h.tau=hh)$est.beta
	}
	beta.hat <- NULL
	for(j in 1:dz){beta.hat <- rbind(beta.hat,apply(Be[,,j],2,mean))}
	# Step 2
	s2 = qrp.sec(y,x,dx,dz,x0,taus=tau,h.tau=hh2,beta=beta.hat,get.se)
	bb = qrp.bias(y,x,dx,dz,x0,taus=tau,h.tau=hh2,h.tau2=hh2,beta=beta.hat,get.se)
	# collect outcomes
	g.hat = s2$est.a0
	bias.est = bb$bias
	B.hat = bb$bhat
	Q.hat = g.hat + t(beta.hat) %*% z0
	if(get.se==1){g.se = s2$se; ga.se = bb$bse}
	if(get.se==0){g.se = NULL; ga.se = NULL}	
	return(list(ghat = g.hat, bias = bias.est, Qhat = Q.hat, beta.hat = beta.hat, B.hat = B.hat, g.se = g.se, ga.se = ga.se))
}

# estimation for a local model (without step 1)
est.s0 <- function(y,x,dx,dz,x0,z0,tau,hh,hh2,get.se){
	s2 = qrp.big(y,x,dx,dz,x0,taus=tau,h.tau=hh2,order=1,get.se)
	bb = qrp.bias.big(y,x,dx,dz,x0,z0,taus=tau,h.tau=hh2,h.tau2=hh2,get.se)
	# collect outcomes
	beta.hat = t(s2$est.beta)
	g.hat = s2$est.a0
	bias.est <- bb$bias
	B.hat = bb$bhat
	Q.hat = g.hat + t(beta.hat) %*% z0
	if(get.se==1){g.se = s2$se; ga.se = bb$bse}
	if(get.se==0){g.se = NULL; ga.se = NULL}	
	return(list(ghat = g.hat, bias = bias.est, Qhat = Q.hat, beta.hat = beta.hat, B.hat = B.hat, g.se = g.se, ga.se = ga.se))
}

qrp.fir <- function(y,x,dx,dz,x0,taus,h.tau){
	# Step 1 in three-steps estimation method (global model)
	# use local quadratic regression
	n = length(y)
	m = length(taus)
	if(dx==1){z = x[,1] - x0}
	if(dx >1){z = x[,1:dx] - t(x0) %x% rep(1,n)}
	z = as.matrix(z)
	if(dz >0){z1 = cbind(poly.quad(z),x[,(dx+1):(dx+dz)])}	
	if(dz==0){z1 = poly.quad(z)}
	coe = NULL		# regression coefficients
	for(k in 1:m){
		wk = apply(depa(z/h.tau[k]),1,prod)
		rk = rq(y ~ z1, tau = taus[k], subset=(wk!=0), w=wk)$coef
		coe = rbind(coe,rk)
	}
	a0 = coe[,1]
	a1 = coe[,2:(1+dx)]
	a2 = coe[,(2+dx):(1+dx+dx*(1+dx)/2)]
	if(dz >0){beta = coe[,(2+dx+dx*(1+dx)/2):(1+dx+dx*(1+dx)/2+dz)]}
	if(dz==0){beta = NULL}
	return(list(est.a0 = a0, est.a1 = a1, est.a2 = a2, est.beta = beta))
}

qrp.sec <- function(y,x,dx,dz,x0,taus,h.tau,beta,get.se=0){
	# Step 2 in three-steps estimation method (global model)
	# use local linear regression
	n = length(y)
	m = length(taus)
	if(dx==1){z = x[,1] - x0}
	if(dx >1){z = x[,1:dx] - t(x0) %x% rep(1,n)}
	z = as.matrix(z)
	coe = NULL; ste = NULL
	for(k in 1:m){
		if(dz >0){yr = y - (x[,(1+dx):(dx+dz)] %*% beta[,k])}
		if(dz==0){yr = y}
		wk = apply(depa(z/h.tau[k]),1,prod)
		a1 = rq(yr ~ z, tau = taus[k], subset=(wk!=0), w = wk)
		coe = rbind(coe,a1$coef)
		if(get.se==1){
			a2 = summary(a1,se="boot")$coef[1,2]
			ste = c(ste,a2)			
		}
	}
	if(get.se==0){return(list(est.a0 = coe[,1], est = coe))}	
	if(get.se==1){return(list(est.a0 = coe[,1], est = coe, se = ste))}
}

qrp.big <- function(y,x,dx,dz,x0,taus,h.tau,order,get.se=0){
	# use it for the local model
	# can use either local linear or quadratic regression
	n = length(y)
	m = length(taus)
	if(dx==1){z = x[,1] - x0}
	if(dx >1){z = x[,1:dx] - t(x0) %x% rep(1,n)}
	z = as.matrix(z)
	if(order==1){
		if(dz >0){z1 = cbind(z,x[,(dx+1):(dx+dz)])}
		if(dz==0){z1 = z}	
	}
	if(order==2){
		if(dz >0){z1 = cbind(poly.quad(z),x[,(dx+1):(dx+dz)])}
		if(dz==0){z1 = poly.quad(z)}	
	}
	coe = NULL; ste = NULL
	for(k in 1:m){
		wk = apply(depa(z/h.tau[k]),1,prod)
		a1 = rq(y ~ z1, tau = taus[k], subset=(wk!=0), w=wk)
		coe = rbind(coe,a1$coef)
		if(get.se==1){
			a2 = summary(a1,se="boot")$coef[1,2]
			ste = c(ste,a2)			
		}
	}
	a0 = coe[,1]
	a1 = coe[,2:(1+dx)]
	if(order==1){a2 = NULL}	
	if(order==2){a2 = coe[,(2+dx):(1+dx+dx*(1+dx)/2)]}
	if(dz==0){beta = NULL}
	if(dz>=1 & order==1){beta = coe[,(2+dx):(1+dx+dz)]}	
	if(dz>=1 & order==2){beta = coe[,(2+dx+dx*(1+dx)/2):(1+dx+dx*(1+dx)/2+dz)]}
	return(list(est.a0 = a0, est.a1 = a1, est.a2 = a2, est.beta = beta, se=ste))
}

# 1.2. Bias estimation

qrp.bias <- function(y,x,dx,dz,x0,taus,h.tau,h.tau2,beta,get.se=0){
	# bias term estimation (for the global model)
	# use local quadratic regression
	# if get.se=1, return standard errors of the bias estimate
	n = length(y)
	m = length(taus)
	if(dx==1){z = x[,1] - x0; z = as.matrix(z)}
	if(dx >1){z = x[,1:dx] - t(x0) %x% rep(1,n)}
	z1 = poly.quad(z)
	chs = (2+dx):(1+dx+dx*(1+dx)/2)
	b.hat = array(0,c(m,1))
	b.se  = array(0,c(m,1))	
	for(k in 1:m){
		if(dz >0){yr = y - (x[,(1+dx):(dx+dz)] %*% beta[,k])}
		if(dz==0){yr = y}
		wk = apply(depa(z/h.tau[k]),1,prod)
		wk2 = apply(depa(z/h.tau2[k]),1,prod)
		a1 = rq(yr ~ z1, tau = taus[k], subset=(wk2!=0), w=wk2)
		gam2 = a1$coef[chs]
		wj = cbind(1,z/h.tau[k])
		qj = cbind(1,poly.quad(z/h.tau[k]))[,chs]
		cj = (solve(crossprod(wj,(wk*wj)))[1,] %*% crossprod(wj,(wk*qj)))
		b.hat[k] = cj %*% gam2		# B.hat
		if(get.se==1){
			a2 = summary(a1,se="boot",cov=T)
			b.se[k] = sqrt(cj %*% a2$cov[chs,chs] %*% t(cj))	# standard error for B.hat	
		}
	}
	bias.e = b.hat*(h.tau^2)		# bias estimste
	if(get.se==0){
		return(list(bias = bias.e, bhat = b.hat))
	}
	if(get.se==1){
		bias.s = b.se*(h.tau^2)		# standard error for the bias
		return(list(bias = bias.e, bias.es = bias.s, bhat = b.hat, bse = b.se))
	}
}

qrp.bias.big <- function(y,x,dx,dz,x0,z0,taus,h.tau,h.tau2,get.se=0){
	# bias estimation for the local model (without Step 1)
	# use local quadratic regression
	# if get.se=1, return standard errors
	n = length(y)
	m = length(taus)
	z.eval = c(1,z0)
	if(dx==1){
		x = as.matrix(x); z = x[,1] - x0; chs = (2+dx+dz):(1+2*dx+dz)}
	if(dx >1){z = x[,1:dx] - t(x0) %x% rep(1,n)
		z1 = poly.quad(z)
		chs = (2+dz+dx):(1+dz+dx+dx*(1+dx)/2)}
	if(dz==0){w = NULL}
	if(dz >0){w = x[,(dx+1):(dx+dz)]}
	b.hat = array(0,c(m,1))
	b.se  = array(0,c(m,1))
	for(k in 1:m){
		if(dx==1){
			wk = depa(z/h.tau[k])
			wk2 = depa(z/h.tau2[k])	
			if(dz==0){mdl = y ~ z + I(z^2)}
			if(dz >0){mdl = y ~ w + z + I(z^2)}
		}
		if(dx>1){
			wk = apply(depa(z/h.tau[k]),1,prod)
			wk2 = apply(depa(z/h.tau2[k]),1,prod)
			if(dz==0){mdl = y ~ z1}
			if(dz >0){mdl = y ~ w + z1}
		}
		a1 = rq(mdl, tau = taus[k], subset=(wk2!=0), weights=wk2)
		gam2 = a1$coef[chs]
		zh = z/h.tau[k]
		if(dz==0 & dx==1){
			wj = cbind(1,zh); qj = zh^2
			cj = solve(crossprod(wj,(wk*wj)))[1,] %*% crossprod(wj,(wk*qj))
			b.hat[k,1] = cj %*% gam2	
		}
		if(dz>0 & dx==1){
			wj = cbind(1,w,zh)
			qj = zh^2
			cj = solve(crossprod(wj,(wk*wj))) %*% crossprod(wj,(wk*qj))
			b.hat[k,1] = (z.eval %*% cj[1:(1+dz)]) %*% gam2
		}
		if(dx>1){
			wj = cbind(1,w,zh)
			qj = poly.quad(zh)[,(1+dx):(dx+dx*(1+dx)/2)]
			cj = solve(crossprod(wj,(wk*wj))) %*% crossprod(wj,(wk*qj))
			b.hat[k,1] = z.eval %*% (cj %*% gam2)[1:(1+dz)]
		}
		if(get.se==1){
			a2 = summary(a1,se="boot",cov=T)
			cj2 = z.eval %*% cj[1:(1+dz),]
			b.se[k,1] = sqrt(cj2 %*% a2$cov[chs,chs] %*% t(cj2))
		}
	}
	bias.e = b.hat*(h.tau^2)		# point estimste
	if(get.se==0){return(list(bias = bias.e, bhat = b.hat))}
	if(get.se==1){
		bias.s = b.se*(h.tau^2)		# standard error
		return(list(bias = bias.e, bias.es = bias.s, bhat = b.hat, bse = b.se))
	}
}

# 1.3. Conditional density estimation

condf.est <- function(x, x0, g.est, dx, dz, taus, taul, h.tau, beta, delta){
	# estimate the average conditional densities
	# use the differencing method
	n = nrow(x)
	m = length(taus)
	if(dx==1){z = x[,1] - x0}
	if(dx >1){z = x[,1:dx] - t(x0) %x% rep(1,n)}
	z = as.matrix(z)
	ffa = array(0,c(n,m))
	for(ii in 1:n){
		if(dz==0){Qh = g.est}
		if(dz >0){Qh = g.est + t(beta) %*% x[ii,(1+dx):(dx+dz)]}
		Qh  = sort(Qh)
		Q.u = approx(x=taul,y=Qh,xout=(taus+delta),method="linear",rule=2)$y
		Q.l = approx(x=taul,y=Qh,xout=(taus-delta),method="linear",rule=2)$y
		ffa[ii,] <- pmax(0,(2*delta)/(Q.u-Q.l-0.01))
	}
	af = array(0,c(1,m))
	for(k in 1:m){
		wk = apply(depa(z/h.tau[k]),1,prod)
		af[k] = sum(ffa[,k]*wk)/(n*h.tau[k]^{dx})
	}
	return(list(fqx = af, ff = ffa))
}

# 1.4. Uniform confidence bands

band.asy <- function(y,x,dx,dz,x0,taus,h.tau,h.tau2,beta,Qy,fqx,bias,alpha,n.sim){
	# uniform bands based on asymptotic approximation (Wald band)
	n = length(y)
	m = length(taus)
	if(dx==1){z = x[,1] - x0}
	if(dx >1){z = x[,1:dx] - t(x0) %x% rep(1,n)}
	z = as.matrix(z)
	chs = (2+dx):(1+dx+dx*(1+dx)/2)
	u.mat = matrix(runif(n*n.sim),nrow=n,ncol=n.sim)
	Gs = array(0,c(m,n.sim))		# save outcomes for the conventional band
	Gr = array(0,c(m,n.sim))		# save outcomes for the robust band
	for(k in 1:m){
		if(dz >0){yr = y - (x[,(1+dx):(dx+dz)] %*% beta[,k])}
		if(dz==0){yr = y}
		wk  = apply(depa(z/h.tau[k]),1,prod)
		wk2 = apply(depa(z/h.tau2[k]),1,prod)
		wj  = cbind(1,z/h.tau[k])
		qj  = cbind(1,poly.quad(z/h.tau[k]))[,chs]
		wj2 = cbind(1,poly.quad(z/h.tau2[k]))
		en1 = n*(h.tau[k]^{dx})
		en2 = n*(h.tau2[k]^{dx})
		q1  = solve(matl(wj,wj,(wk*fqx[,k]))/en1)
		q2  = solve(matl(wj,wj,wk)/en1)
		p2  = matl(wj,qj,wk)/en1
		q3  = solve(matl(wj2,wj2,(wk2*fqx[,k]))/en2)
		for(j in 1:n.sim){
			uu = taus[k] - (u.mat[,j] <= taus[k])
			p1 = apply(((uu*wk)*wj),2,sum)/sqrt(en1)
			p3 = apply(((uu*wk2)*wj2),2,sum)/sqrt(en2)
			d1 = (q1 %*% p1)[1]
			if(dx==1){d2 = (q2 %*% p2)[1]*(q3 %*% p3)[chs]}
			if(dx >1){d2 = (q2 %*% p2)[1,] %*% (q3 %*% p3)[chs]}
			r1 = (h.tau[k]/h.tau2[k])^{(dx+4)/2}
			Gs[k,j] = d1
			Gr[k,j] = d1 - r1*d2
		}
	}
	# uniform band
	shat = sqrt(apply((Gs*Gs),1,mean))
	ra = Gs/matrix(rep(shat,n.sim),ncol=n.sim)
	rs = apply(abs(ra),2,max)
	cp = quantile(rs,probs=alpha)
	sigma = shat/sqrt(n*(h.tau^{dx}))
	
	# robust uniform band
	shat2 = sqrt(apply((Gr*Gr),1,mean))
	ra2 = Gr/matrix(rep(shat2,n.sim),ncol=n.sim)
	rs2 = apply(abs(ra2),2,max)
	cp2 = quantile(rs2,probs=alpha)
	sigma2 = shat2/sqrt(n*(h.tau^{dx}))
	
	# save robust bands
	if(length(alpha)==1){
		uci = cbind((Qy - cp*sigma),(Qy + cp*sigma))
		uci.r = cbind((Qy - bias - cp2*sigma2),(Qy - bias + cp2*sigma2))
	}
	if(length(alpha)>1){
		uci = array(0,c(m,2,length(alpha))); uci.r = uci
		for(ii in 1:length(alpha)){
			uci[,,ii] = cbind((Qy - cp[ii]*sigma),(Qy + cp[ii]*sigma))
			uci.r[,,ii] = cbind((Qy - bias - cp2[ii]*sigma2),(Qy - bias + cp2[ii]*sigma2))
		}
	}
	# pointwise bands
	pci = array(0,c(m,2,length(alpha))); pci.r = pci
	for(ii in 1:length(alpha)){
		pl  = apply(ra,1,quantile,probs=((1-alpha[ii])/2))
		pr  = apply(ra,1,quantile,probs=((1+alpha[ii])/2))
		pci[,,ii] = cbind((Qy + pl*sigma),(Qy + pr*sigma))
		pl2 = apply(ra2,1,quantile,probs=((1-alpha[ii])/2))
		pr2 = apply(ra2,1,quantile,probs=((1+alpha[ii])/2))
		pci.r[,,ii] = cbind((Qy - bias + pl2*sigma2),(Qy - bias + pr2*sigma2))		
	}
	return(list(est = Qy, est.adj = (Qy-bias), uband = uci, uband.r = uci.r, pband = pci, pband.r = pci.r, dc = Gs, dr = Gr))
}

band.asy.big <- function(y,x,dx,dz,x0,taus,h.tau,h.tau2,Qy,fqx,bias,alpha,n.sim){
	# uniform bands based on asymptotic approximation (Wald band)
	# Big data option - use it for the local model
	n = length(y)
	m = length(taus)
	if(dx==1){z = x[,1] - x0; w = x[,2:(1+dz)]}
	if(dx >1){z = x[,1:dx] - t(x0) %x% rep(1,n); w = x[,(1+dx):(dx+dz)]}
	z = as.matrix(z)
	chs = (2+dz+dx):(1+dz+dx+dx*(1+dx)/2)
	u.mat = matrix(runif(n*n.sim),nrow=n,ncol=n.sim)
	Gs = array(0,c(m,n.sim))		# save outcomes for the conventional band
	Gr = array(0,c(m,n.sim))		# save outcomes for the robust band
	for(k in 1:m){
		wk  = apply(depa(z/h.tau[k]),1,prod)
		wk2 = apply(depa(z/h.tau2[k]),1,prod)
		zh  = z/h.tau[k]
		wj  = cbind(1,w,zh)
		if(dx==1){qj  = zh^2}
		if(dx >1){qj  = poly.quad(zh)[,(1+dx):(dx+dx*(1+dx)/2)]}
		wj2 = cbind(wj,qj)
		en1 = n*(h.tau[k]^{dx})
		en2 = n*(h.tau2[k]^{dx})
		q1  = solve(matl(wj,wj,(wk*fqx[,k]))/en1)
		q2  = solve(matl(wj,wj,wk)/en1)
		p2  = matl(wj,qj,wk)/en1
		q3  = solve(matl(wj2,wj2,(wk2*fqx[,k]))/en2)
		for(j in 1:n.sim){
			uu = taus[k] - (u.mat[,j] <= taus[k])
			p1 = apply(((uu*wk)*wj),2,sum)/sqrt(en1)
			p3 = apply(((uu*wk2)*wj2),2,sum)/sqrt(en2)
			d1 = c(1,z0) %*% (q1 %*% p1)[1:(1+dz)]
			if(dx==1){d2 = (c(1,z0) %*% (q2 %*% p2)[1:(1+dz)])*(q3 %*% p3)[chs]}
			if(dx >1){d2 = (c(1,z0) %*% (q2 %*% p2)[1:(1+dz),]) %*% (q3 %*% p3)[chs]}
			r1 = (h.tau[k]/h.tau2[k])^{(dx+4)/2}
			Gs[k,j] = d1
			Gr[k,j] = d1 - r1*d2
		}
	}
	# uniform band
	shat = sqrt(apply((Gs*Gs),1,mean))
	ra = Gs/matrix(rep(shat,n.sim),ncol=n.sim)
	rs = apply(abs(ra),2,max)
	cp = quantile(rs,probs=alpha)
	sigma = shat/sqrt(n*(h.tau^{dx}))
	
	# robust uniform band
	shat2 = sqrt(apply((Gr*Gr),1,mean))
	ra2 = Gr/matrix(rep(shat2,n.sim),ncol=n.sim)
	rs2 = apply(abs(ra2),2,max)
	cp2 = quantile(rs2,probs=alpha)
	sigma2 = shat2/sqrt(n*(h.tau^{dx}))
	
	# save robust bands
	if(length(alpha)==1){
		uci = cbind((Qy - cp*sigma),(Qy + cp*sigma))
		uci.r = cbind((Qy - bias - cp2*sigma2),(Qy - bias + cp2*sigma2))
	}
	if(length(alpha)>1){
		uci = array(0,c(m,2,length(alpha))); uci.r = uci
		for(ii in 1:length(alpha)){
			uci[,,ii] = cbind((Qy - cp[ii]*sigma),(Qy + cp[ii]*sigma))
			uci.r[,,ii] = cbind((Qy - bias - cp2[ii]*sigma2),(Qy - bias + cp2[ii]*sigma2))
		}
	}
	return(list(est = Qy, est.adj = (Qy-bias), uband = uci, uband.r = uci.r, dc = Gs, dr = Gr))
}

# 1.5. Uniform Score band

band.res <- function(y,x,dx,dz,x0,taus,h.tau,h.tau2,beta,Qy,ghat,bias,bhat,gse,bse,alpha,n.sim,con){
	# uniform bands based on resampling (Score band)
	n = length(y)
	m = length(taus)
	if(dx==1){z = x[,1] - x0}
	if(dx >1){z = x[,1:dx] - t(x0) %x% rep(1,n)}
	z  = as.matrix(z)
	z2 = poly.quad(z)
	chs = (2+dx):(1+dx+dx*(1+dx)/2)
	u.mat = matrix(runif(n*n.sim),nrow=n,ncol=n.sim)
	Hs = array(0,c(m,n.sim))	# save outcomes for the conventional band
	Hr = array(0,c(m,n.sim))	# save outcomes for the robust band
	Ds = array(0,c(m,n.sim))	# save sign of the inequality constraint
	Dr = array(0,c(m,n.sim))	# save sign of the inequality constraint
	for(k in 1:m){
		if(dz >0){yr = y - (x[,(1+dx):(dx+dz)] %*% beta[,k])}
		if(dz==0){yr = y}
		wk = apply(depa(z/h.tau[k]),1,prod)
		wk2 = apply(depa(z/h.tau2[k]),1,prod)
		wj = cbind(1,z/h.tau[k])
		qj = cbind(1,poly.quad(z/h.tau[k]))[,chs]
		yn = 10000
		ynew = c(yr,yn)
		for(j in 1:n.sim){
			uu = taus[k] - (u.mat[,j] <= taus[k])
			xn.0 = sum(uu*wk)/taus[k]
			xn.1 = apply(z*(uu*wk),2,sum)/taus[k]
			xn = c(xn.0,xn.1)
			xnew = rbind(cbind(1,z),xn)
			astar = rq(ynew ~ xnew-1,R = -t(xn),r = -yn,method ="fnc",tau=taus[k],w=c(wk,1))$coef
			Hs[k,j] = astar[1]
			Ds[k,j] = (yn <= crossprod(astar,xn))
			# for robust band
			xr.0 = sum(uu*wk2)/taus[k]
			xr.1 = apply(z2*(uu*wk2),2,sum)/taus[k]
			xr = c(xr.0,xr.1)
			xnew.r = rbind(cbind(1,z2),xr)
			gstar = rq(ynew ~ xnew.r-1,R = -t(xr),r = -yn,method ="fnc",tau=taus[k],w=c(wk2,1))$coef
			Hr[k,j] = (solve(crossprod(wj,(wk*wj)))[1,] %*% crossprod(wj,(wk*qj))) %*% gstar[chs]
			Dr[k,j] = (yn <= crossprod(gstar,xr))
		}
	}
	# resampling outcomes
	out1 = Hs - matrix(rep(ghat,n.sim),ncol=n.sim)
	out2 = Hr - matrix(rep(bhat,n.sim),ncol=n.sim)
	# exclude extreme realisations
	f1 = abs(out1) > con*matrix(rep(gse,n.sim),ncol=n.sim)
	f2 = abs(out2) > con*matrix(rep(bse,n.sim),ncol=n.sim)
	flag = apply(rbind(f1,f2),2,max)
	
	# uniform band
	as = out1[,(flag==0)]
	shat = sqrt(apply((as*as),1,mean))
	#shat = apply(as,1,IQR)/1.34
	ra = as/matrix(rep(shat,ncol(as)),ncol=ncol(as))
	rs = apply(abs(ra),2,max)
	cp = quantile(rs,probs=alpha)
	
	# robust band
	out3 = out1 - out2*matrix(rep((h.tau^2),n.sim),ncol=n.sim)
	ar = out3[,(flag==0)]
	shat2 = sqrt(apply((ar*ar),1,mean))
	#shat2 = apply(ar,1,IQR)/1.34
	ra2 = ar/matrix(rep(shat2,ncol(ar)),ncol=ncol(ar))
	rs2 = apply(abs(ra2),2,max)
	cp2 = quantile(rs2,probs=alpha)
	
	# save bands
	if(length(alpha)==1){
		uci = cbind((Qy - cp*shat),(Qy + cp*shat))
		uci.r = cbind((Qy - bias - cp2*shat2),(Qy - bias + cp2*shat2))
	}
	if(length(alpha)>1){
		uci = array(0,c(m,2,length(alpha))); uci.r = uci
		for(ii in 1:length(alpha)){
			uci[,,ii] = cbind((Qy - cp[ii]*shat),(Qy + cp[ii]*shat))
			uci.r[,,ii] = cbind((Qy - bias - cp2[ii]*shat2),(Qy - bias + cp2[ii]*shat2))	
		}
	}
	return(list(uband=uci, uband.r = uci.r, sgn1 = Ds, sgn2 = Dr, flag=flag, dc = as, dr = ar))
}

band.res.big <- function(y,x,dx,dz,x0,z0,taus,h.tau,h.tau2,Qy,ghat,bias,bhat,gse,bse,alpha,n.sim,con){
	# uniform bands based on resampling (Score band)
	# Big data option, use it for the local model
	n = length(y)
	m = length(taus)
	if(dx==1){z = x[,1] - x0; w = x[,2:(1+dz)]}
	if(dx >1){z = x[,1:dx] - t(x0) %x% rep(1,n); w = x[,(1+dx):(dx+dz)]}	
	z  = as.matrix(z)
	z2 = poly.quad(z)
	chs = (2+dz+dx):(1+dz+dx+dx*(1+dx)/2)
	u.mat = matrix(runif(n*n.sim),nrow=n,ncol=n.sim)
	Hs = array(0,c(m,n.sim))	# save outcomes for the conventional band
	Hr = array(0,c(m,n.sim))	# save outcomes for the robust band
	Ds = array(0,c(m,n.sim))	# save sign of the inequality constraint
	Dr = array(0,c(m,n.sim))	# save sign of the inequality constraint
	for(k in 1:m){
		wk = apply(depa(z/h.tau[k]),1,prod)
		wk2 = apply(depa(z/h.tau2[k]),1,prod)
		zh = z/h.tau[k]
		wj = cbind(1,w,zh)
		if(dx==1){qj = zh^2}
		if(dx >1){qj = poly.quad(zh)[,(1+dx):(dx+dx*(1+dx)/2)]}
		yn = 10000
		ynew = c(y,yn)
		for(j in 1:n.sim){
			uu = taus[k] - (u.mat[,j] <= taus[k])
			xn.0 = sum(uu*wk)/taus[k]
			xn.1 = apply(z*(uu*wk),2,sum)/taus[k]
			wn = apply(w*(uu*wk),2,sum)/taus[k]
			xn = c(xn.0,wn,xn.1)
			xnew = rbind(cbind(1,w,z),xn)
			astar = rq(ynew ~ xnew-1,R = -t(xn),r = -yn,method ="fnc",tau=taus[k],w=c(wk,1))$coef
			Hs[k,j] = c(1,z0) %*% astar[1:(1+dz)]
			Ds[k,j] = (yn <= crossprod(astar,xn))
			# for robust band
			xr.0 = sum(uu*wk2)/taus[k]
			xr.1 = apply(z2*(uu*wk2),2,sum)/taus[k]
			wr = apply(w*(uu*wk2),2,sum)/taus[k]
			xr = c(xr.0,wr,xr.1)
			xnew.r = rbind(cbind(1,w,z2),xr)
			gstar = rq(ynew ~ xnew.r-1,R = -t(xr),r = -yn,method ="fnc",tau=taus[k],w=c(wk2,1))$coef
			Hr[k,j] = c(1,z0) %*% solve(crossprod(wj,(wk*wj)))[1:(1+dz),] %*% crossprod(wj,(wk*qj)) %*% gstar[chs]
			Dr[k,j] = (yn <= crossprod(gstar,xr))
		}
	}
	# resampling outcomes
	out1 = Hs - matrix(rep(ghat,n.sim),ncol=n.sim)
	out2 = Hr - matrix(rep(bhat,n.sim),ncol=n.sim)
	# exclude extreme realizations
	f1 = abs(out1) > con*matrix(rep(gse,n.sim),ncol=n.sim)
	f2 = abs(out2) > con*matrix(rep(bse,n.sim),ncol=n.sim)
	flag = apply(rbind(f1,f2),2,max)
	
	# uniform band
	as = out1[,(flag==0)]
	shat = sqrt(apply((as*as),1,mean))
	#shat = apply(as,1,IQR)/1.34	# alternative method
	ra = as/matrix(rep(shat,ncol(as)),ncol=ncol(as))
	rs = apply(abs(ra),2,max)
	cp = quantile(rs,probs=alpha)
	
	# robust band
	out3 = out1 - out2*matrix(rep((h.tau^2),n.sim),ncol=n.sim)
	ar = out3[,(flag==0)]
	shat2 = sqrt(apply((ar*ar),1,mean))
	#shat2 = apply(ar,1,IQR)/1.34	# alternative method
	ra2 = ar/matrix(rep(shat2,ncol(ar)),ncol=ncol(ar))
	rs2 = apply(abs(ra2),2,max)
	cp2 = quantile(rs2,probs=alpha)
	
	# save bands
	if(length(alpha)==1){
		uci = cbind((Qy - cp*shat),(Qy + cp*shat))
		uci.r = cbind((Qy - bias - cp2*shat2),(Qy - bias + cp2*shat2))
	}
	if(length(alpha)>1){
		uci = array(0,c(m,2,length(alpha))); uci.r = uci
		for(ii in 1:length(alpha)){
			uci[,,ii] = cbind((Qy - cp[ii]*shat),(Qy + cp[ii]*shat))
			uci.r[,,ii] = cbind((Qy - bias - cp2[ii]*shat2),(Qy - bias + cp2[ii]*shat2))	
		}
	}
	return(list(uband=uci, uband.r = uci.r, sgn1 = Ds, sgn2 = Dr, flag=flag, dc = as, dr = ar))
}

# 1.6. make bands. Use it only for the RDD

make.band.rdd <- function(n.sam,Dc.p,Dc.m,Dr.p,Dr.m,dx,dz,taus,hh,Qy.p,Qy.m,bias.p,bias.m,alpha,type){
	# take simulated values and make bands
	if(dz==0) stop("dz must be one or bigger")
	m = length(taus)
	Qd = Qy.p - Qy.m
	Qd.adj = Qd - (bias.p - bias.m)
	uci = array(0,c(m,2,length(alpha))); uci.r = uci

	if(type==1){ # Wald band
	Gs = Dc.p - Dc.m
	Gr = Dr.p - Dr.m
	Gs = sqrt(2)*Gs	# added to take into account that the sample size is doubled in RDD setup in simulation
	Gr = sqrt(2)*Gr
	
	# uniform band
	if(m==1){shat = sqrt(mean(Gs*Gs))}
	if(m >1){shat = sqrt(apply((Gs*Gs),1,mean))}
	ra = Gs/matrix(rep(shat,ncol(Gs)),ncol=ncol(Gs))
	rs = apply(abs(ra),2,max)
	cp = quantile(rs,probs=alpha)
	sigma = shat/sqrt(n.sam*(hh^{dx}))

	# robust uniform band
	if(m==1){shat2 = sqrt(mean(Gr*Gr))}
	if(m >1){shat2 = sqrt(apply((Gr*Gr),1,mean))}
	ra2 = Gr/matrix(rep(shat2,ncol(Gr)),ncol=ncol(Gr))
	rs2 = apply(abs(ra2),2,max)
	cp2 = quantile(rs2,probs=alpha)
	sigma2 = shat2/sqrt(n.sam*(hh^{dx}))
		
	for(ii in 1:length(alpha)){
		uci[,,ii] = cbind((Qd - cp[ii]*sigma),(Qd + cp[ii]*sigma))
		uci.r[,,ii] = cbind((Qd.adj - cp2[ii]*sigma2),(Qd.adj + cp2[ii]*sigma2))
	}
	}
	if(type==2){ # Score bands
	c1 = min(ncol(Dc.p),ncol(Dc.m))
	c2 = min(ncol(Dr.p),ncol(Dr.m))
	Gs = Dc.p[,1:c1] - Dc.m[,1:c1]
	Gr = Dr.p[,1:c2] - Dr.m[,1:c2]

	# uniform band
	shat = sqrt(apply((Gs*Gs),1,mean))
	ra = Gs/matrix(rep(shat,ncol(Gs)),ncol=ncol(Gs))
	rs = apply(abs(ra),2,max)
	cp = quantile(rs,probs=alpha)
	
	# robust band
	shat2 = sqrt(apply((Gr*Gr),1,mean))
	ra2 = Gr/matrix(rep(shat2,ncol(Gr)),ncol=ncol(Gr))
	rs2 = apply(abs(ra2),2,max)
	cp2 = quantile(rs2,probs=alpha)
	
	for(ii in 1:length(alpha)){
		uci[,,ii] = cbind((Qd - cp[ii]*shat),(Qd + cp[ii]*shat))
		uci.r[,,ii] = cbind((Qd.adj - cp2[ii]*shat2),(Qd.adj + cp2[ii]*shat2))	
	}
	}
	return(list(qte = Qd, qte.r = Qd.adj, uband = uci, uband.r = uci.r))
}

# 1.7. Bandwidth selection

bandwidth.cv <- function(y, x, dx, dz, x0, order, opt = 2){
	# cv bandwidth for the partially linear model
	# order = 1, use the local linear regression. order=2, use the local quadratic regression
	# option=1 is very specific to the simulation exercise, option=2 can be more general
	n  = length(y)
	# Determine evaluation points - currently even if dx>2, use only the first two columns in x
	if(opt==1){	# assumes that x is from uniform distribution
	if(dx==1){
		z0 = x[,1] - x0
		zq = quantile(abs(z0),probs=0.5)
		index = which(abs(z0) <= zq) 
	}
	if(dx >1){
		z0 = x[,1:dx] - t(x0) %x% rep(1,n)
		zq1 = quantile(abs(z0[,1]),probs=0.7)	# use the closest 50% of observations
		zq2 = quantile(abs(z0[,2]),probs=0.7)
		index = which((abs(z0[,1]) <= zq1) & (abs(z0[,2] <= zq2)))		
	}
	}
	if(opt==2){
	if(dx==1){
		f1 = ecdf(x[,1])
		ux = f1(x[,1])
		b0 = max((f1(x0)-0.25),f1(min(x[,1])))
		b1 = min((f1(x0)+0.25),f1(max(x[,1])))
		index = which((ux >= b0) & (ux <= b1))
	}
	if(dx >1){
		f1 = ecdf(x[,1]); f2 = ecdf(x[,2])
		ux1 = f1(x[,1]);  ux2 = f2(x[,2])
		b0 = max((f1(x0[1])-0.35),f1(min(x[,1])))
		b1 = min((f1(x0[1])+0.35),f1(max(x[,1])))
		d0 = max((f2(x0[2])-0.35),f2(min(x[,2])))
		d1 = min((f2(x0[2])+0.35),f2(max(x[,2])))
		index = which((ux1 >= b0) & (ux1 <= b1) & (ux2 >= d0) & (ux2 <= d1))
	}
	}
	# candidate values
	if(opt==1){bd = seq(0.25,1.0,length.out=15)}
	if(opt==2){
		if(dx==1){bm = max(x[,1])-min(x[,1])}
		if(dx >1){bm = max(diff(range(x[,1])),diff(range(x[,2])))}
		bd = seq(0.25*bm,bm,length.out=15)	# candidate values
	}	
	if(order==1){sel = (1+dx+1):(1+dx+dz)}
	if(order==2){sel = (1+dx+dx*(dx+1)/2+1):(1+dx+dx*(dx+1)/2+dz)}
	cri <- array(0,c(length(bd),1))
	for(i in 1:length(bd)){
		cri.h <- NULL
		for (j in index){
			if(dx==1){z <- x[,1] - x[j,1]; z <- as.matrix(z)}
			if(dx >1){z <- x[,1:dx] - t(x[j,1:dx]) %x% rep(1,n)}	
			wx = apply(depa(z/bd[i]),1,prod)
			if(order==1){
				if(dz >0){xs <- cbind(z,x[,(1+dx):(dx+dz)])}
				if(dz==0){xs <- z}
			}
			if(order==2){
				if(dz >0){xs <- cbind(poly.quad(z),x[,(1+dx):(dx+dz)])}
				if(dz==0){xs <- poly.quad(z)}
			}
			coe <- rq(y[-j] ~ xs[-j,], tau = 0.5, w = wx[-j])$coef
			if(dz >0){Qy <- coe[1] + crossprod(coe[sel],x[j,(1+dx):(dx+dz)])}
			if(dz==0){Qy <- coe[1]}
			cri.h <- c(cri.h,abs(y[j]-Qy))
		}
		cri[i] <- mean(cri.h)
	}
	return(list(h.cv = bd[which.min(cri)], cand = cbind(bd,cri)))
}

bandwidth.opt <- function(y, x, dx, dz, x0, Qy, beta, band, delta, bdy=0){
	# optimal bandwidth at the median
	# if bdy=0, uses interior point formula to estimate the trace term
	if(length(Qy) != 3)
		stop("Dimension of Qy is wrong")
	n <- length(y)
	p <- dx
	if(dx==1){z = x[,1] - x0}
	if(dx >1){z = x[,1:dx] - t(x0) %x% rep(1,n)}
	z = as.matrix(z)
	wx = apply(depa(z/band),1,prod)
	# step 1: trace of hessian
	zz = poly.quad(z)
	chs = (2+dx):(1+dx+dx*(1+dx)/2)	
	if(dz >0){yr = y - (x[,(1+dx):(dx+dz)] %*% beta[,2])}
	if(dz==0){yr = y}
	coe = rq(yr ~ zz, tau = 0.5, w = wx)$coef[chs]
	z2 = cbind(1,poly.quad(z/band))[,chs]
	if(bdy==0){	# interior point formula for trace estiamtion
		z2 = as.matrix(z2)
		tr.h = (apply((z2*wx),2,sum)/sum(wx)) %*% coe
	}
	if(bdy==1){	# boundary point formula for trace estiamtion
		z.tau = cbind(1,z/band)
		cj  = (solve(matl(z.tau,z.tau,wx))[1,] %*% matl(z.tau,z2,wx))
		tr.h = cj %*% coe
	}
	tr = 2*tr.h
	# step 2: average conditional density
	ffa <- array(0,c(n,1))
	for(ii in 1:n){
		if(dz >0){
			Q.u = Qy[3] + crossprod(beta[,3],x[ii,(1+dx):(dx+dz)])
			Q.l = Qy[1] + crossprod(beta[,1],x[ii,(1+dx):(dx+dz)])			
		}
		if(dz==0){
			Q.u = Qy[3]; Q.l = Qy[1]			
		}
		fc <- (2*delta)/(Q.u-Q.l-0.01)
		ffa[ii] <- max(0,fc)
	}
	af = sum(ffa*wx)/(n*(band^{p}))
	fx = sum(wx)/(n*(band^{p}))
	# step 3: put things together
	d2 = (tr^{2})*(af^{2})/fx
	# step 4: numerator
	d1 = 0.5*0.5*dx*(3/5)
	h.op = ((d1/d2)^{1/(4+p)})*(n^{-1/(4+p)})
	return(list(h.op = h.op))
}

#########################################
## 2. Functions for the Unemployment Insurance application

condf.est.het <- function(x, dx, dz, z0, Q, bcoe, taus, taul, delta, case){
	# estimate the average conditional densities by differencing
	# used in application
	# case=1 for dummy covariates, case=2 for continuous covariates
	if(dz==0){n = length(x); w = NULL}
	if(dz!=0){n = nrow(x);   w = as.matrix(x[,(1+dx):(dx+dz)])}
	if(case==1){dg = dz+1}	
	if(case==2){dg = length(z0)}
	m = length(taus)
	ff = array(0,c(n,m))
	if(case==1){
		ffa = array(0,c(m,dg))
		for(j in 1:dg){
			if(dz==0){Qh  = sort(Q)}
			if(dz!=0){Qh  = sort(Q[,j])}
			Q.u = approx(x=taul,y=Qh,xout=(taus+delta),method="linear",rule=2)$y
			Q.l = approx(x=taul,y=Qh,xout=(taus-delta),method="linear",rule=2)$y
			ffa[,j] <- pmax(0,(2*delta)/(Q.u-Q.l-0.01))
		}
		if(dz==0){
			for(i in 1:n){ff[i,] = ffa[,1]}
		}
		if(dz>=1){
			for(i in 1:n){
				wq = sum(w[i,])
				if(wq==0){jj = 1}
				if(wq==1){jj = which(w[i,]==1)+1}
				ff[i,] = ffa[,jj]
			}
		}
	}
	if(case==2){
		for(i in 1:n){
			#Qh = bcoe[,1] + (bcoe[,2] * w[i,])
			Qh = sort(bcoe %*% c(1,w[i,]))
			Q.u = approx(x=taul,y=Qh,xout=(taus+delta),method="linear",rule=2)$y
			Q.l = approx(x=taul,y=Qh,xout=(taus-delta),method="linear",rule=2)$y
			ff[i,] = pmax(0,(2*delta)/(Q.u-Q.l-0.01))
		}
		ffa = NULL
	}
	return(list(ff = ff, fa = ffa))
}

bias.est.het <- function(y,x,dx,dz,x0,z0,taus,h.tau,h.tau2,fx,se=0){
	# bias term estimation - use local quadratic regression
	# assume dx=1 (for application)
	# if se=1, return standard errors
	m = length(taus)
	n = length(y)
	if(dz==0){z = x - x0; w = NULL; x = as.vector(x); ng = 1}
	if(dz >0){z = x[,1] - x0; w = x[,2:(1+dz)]}
	if(dz==1){ng = length(z0)}
	if(dz >1){ng = nrow(z0)}
	dim.x  = (1+dx)*(1+dz)
	dim.x2 = (1+2*dx)*(1+dz)
	chs = (dim.x+1):dim.x2
	b.hat = array(0,c(m,ng))
	b.se = array(0,c(m,ng))
	for(k in 1:m){
		wk  = depa(z/h.tau[k])
		wk2 = depa(z/h.tau2[k])
		if(dz==0){mdl = y ~ z + I(z^2)}
		if(dz >0){mdl = y ~ w + z + I(w*z) + I(z^2) + I(w*(z^2))}
		a1 = rq(mdl, method="fn", tau = taus[k], weights=wk2)
		gam2 = a1$coef[chs]
		zh = z/h.tau[k]
		if(dz==0){
			wj = cbind(1,zh); qj = zh^2
			cj = solve(crossprod(wj,(wk*wj)))[1,] %*% crossprod(wj,(wk*qj))
			b.hat[k,1] = cj %*% gam2	
		}
		if(dz >0){
			wj = cbind(1,w,zh,(w*zh))
			qj = cbind((zh^2),(w*(zh^2)))
			#wj2 = cbind(xj,qj)
			sel = 1:(1+dz)	
			for(i in 1:ng){
				if(dz==1){zz0 = c(1,z0[i])}
				if(dz >1){zz0 = c(1,z0[i,])}
				cj = solve(crossprod((wj*fx[,k]),(wk*wj))) %*% crossprod((wj*fx[,k]),(wk*qj))
				b.hat[k,i] = zz0 %*% (cj %*% gam2)[sel]
			}
		}
		if(se==1){
			a2 = summary(a1,se="ker",cov=T)
			b.se[k,i] = sqrt(cj %*% a2$cov[chs,chs] %*% t(cj))
		}
	}
	bias.e = b.hat*(h.tau^2)		# point estimste
	if(se==0){return(list(bias = bias.e, bhat = b.hat))}
	if(se==1){
		bias.s = b.se*(h.tau^2)		# standard error
		return(list(bias = bias.e, bias.es = bias.s, bhat = b.hat, bse = b.se))
	}
}

nrq.sim <- function(x,d,x0,z0,dx,dz,tt,hh,hh2,fxp,fxm,n.sim){
	# use it for RDD, dx=1
	# generate the simulated outcomes from the asymptotic distribution
	if(dz==0){x = as.vector(x); n = length(x); z = x - x0; w = NULL; ng = 1}
	if(dz!=0){n = nrow(x); z = x[,1] - x0; w = x[,2:(1+dz)]}
	if(dz==1){ng = length(z0)}
	if(dz>=2){ng = nrow(z0)}
	m = length(tt)
	dim.x  = (1+dx)*(1+dz)
	dim.x2 = (1+2*dx)*(1+dz)
	chs = (dim.x+1):dim.x2
	p1.p = array(0,c(dim.x,m,n.sim))
	p1.m = p1.p
	p3.p = array(0,c(dim.x2,m,n.sim))
	p3.m = p3.p	
	for(j in 1:n.sim){
		u  = runif(n)
		for(k in 1:m){
			kx = depa(z/hh[k])
			kx2 = depa(z/hh2[k])
			en = n*hh[k]
			en2 = n*hh2[k]
			zh = z/hh[k]
			xj = cbind(1,w,zh,(w*zh))
			qj = cbind((zh^2),(w*(zh^2)))
			xj2 = cbind(xj,qj)
			uu = tt[k] - (u <= tt[k])
			p1.p[,k,j] = apply((d*uu*kx*xj),2,sum)/sqrt(en)
			p1.m[,k,j] = apply(((1-d)*uu*kx*xj),2,sum)/sqrt(en)
			p3.p[,k,j] = apply((d*uu*kx2*xj2),2,sum)/sqrt(en2)
			p3.m[,k,j] = apply(((1-d)*uu*kx2*xj2),2,sum)/sqrt(en2)
		}
	}
	Gs = array(0,c(ng,m,n.sim,2))
	Gr = Gs; Gs2 = Gs
	for(k in 1:m){
		kx = depa(z/hh[k])
		kx2 = depa(z/hh2[k])
		en = n*hh[k]
		en2 = n*hh2[k]
		zh = z/hh[k]
		xj = cbind(1,w,zh,(w*zh))
		qj = cbind((zh^2),(w*(zh^2)))
		xj2 = cbind(xj,qj)
		q1.p = solve(crossprod((kx*xj),(d*fxp[,k]*xj))/en)
		q1.m = solve(crossprod((kx*xj),((1-d)*fxm[,k]*xj))/en)
		pp1 = p1.p[,k,]
		pm1 = p1.m[,k,]
		d1p = apply(pp1, 2, function(x) q1.p%*%x)
		d1m = apply(pm1, 2, function(x) q1.m%*%x)
		# for robust band
		q2.p = solve(crossprod((kx*xj),(d*fxp[,k]*xj))/en) 
		q2.m = solve(crossprod((kx*xj),((1-d)*fxm[,k]*xj))/en)
		p2.p = crossprod((d*fxp[,k]*xj),(kx*qj))/en
		p2.m = crossprod(((1-d)*fxm[,k]*xj),(kx*qj))/en
		d2p = q2.p %*% p2.p
		d2m = q2.m %*% p2.m
		q3.p  = solve(crossprod((kx2*xj2),(d*fxp[,k]*xj2))/en2)
		q3.m  = solve(crossprod((kx2*xj2),((1-d)*fxm[,k]*xj2))/en2)
		pp3 = p3.p[,k,]
		pm3 = p3.m[,k,]
		d3p = apply(pp3, 2, function(x) q3.p %*% x)
		d3m = apply(pm3, 2, function(x) q3.m %*% x)
		r1 = (hh[k]/hh2[k])^{(dx+4)/2}
		# collect outcomes
		if(dz==0){
			Gs[1,k,,1] = d1p[1,]
			Gs[1,k,,2] = d1m[1,]
			Gr[1,k,,1] = d1p[1,] - r1*d2p[1,]*d3p[chs,] # assumes that dx=1
			Gr[1,k,,2] = d1m[1,] - r1*d2m[1,]*d3m[chs,]			
		}
		if(dz >0){
		for(i in 1:ng){
			if(dz==1){z.eval = c(1,z0[i])}
			if(dz>=2){z.eval = c(1,z0[i,])}
			Gs[i,k,,1] = apply(d1p[1:(1+dz),], 2, function(x) crossprod(z.eval,x))
			Gs[i,k,,2] = apply(d1m[1:(1+dz),], 2, function(x) crossprod(z.eval,x))
			d21p = z.eval %*% d2p[1:(1+dz),]
			d21m = z.eval %*% d2m[1:(1+dz),]
			Gr[i,k,,1] = Gs[i,k,,1] - r1*apply(d3p[chs,], 2, function(x) d21p %*% x)
			Gr[i,k,,2] = Gs[i,k,,2] - r1*apply(d3m[chs,], 2, function(x) d21m %*% x)
		}
		}
	}
	return(list(dcp = Gs[,,,1], dcm = Gs[,,,2], drp = Gr[,,,1], drm = Gr[,,,2]))
}

make.band.het <- function(n.sam,Dc.p,Dc.m,Dr.p,Dr.m,dx,dz,taus,hh,Qy.p,Qy.m,bias.p,bias.m,alpha,n.sim){
	# Uniform bands based on asymptotic distribution
	# accept simulated values from nrq.sim() and construct bands
	# 'uband' is the uniform band, 'uband.r' is the robust uniform band
	m = length(taus)
	if(dz==0){
		dim(Dc.p) = c(1,m,n.sim); dim(Dc.m) = c(1,m,n.sim)
		dim(Dr.p) = c(1,m,n.sim); dim(Dr.m) = c(1,m,n.sim)
	}
	ng = dim(Dc.p)[1]
	uci = array(0,c(m,2,ng))
	uci.r = uci
	Qd = array(0,c(m,ng))
	Qd.adj = Qd
	sig = array(0,c(m,ng)); sig.r = sig
	for(i in 1:ng){
		Gs = Dc.p[i,,] - Dc.m[i,,]
		Gr = Dr.p[i,,] - Dr.m[i,,]
		Qy = Qy.p[,i] - Qy.m[,i]
		Qy.adj = Qy - (bias.p[,i] - bias.m[,i])

		# uniform band
		if(m==1){shat = sqrt(mean(Gs*Gs))}
		if(m >1){shat = sqrt(apply((Gs*Gs),1,mean))}
		ra = Gs/matrix(rep(shat,n.sim),ncol=n.sim)
		rs = apply(abs(ra),2,max)
		cp = quantile(rs,probs=alpha)
		sigma = shat/sqrt(n.sam*(hh^{dx}))
		uci[,,i] = cbind((Qy - cp*sigma),(Qy + cp*sigma))

		# robust uniform band
		if(m==1){shat2 = sqrt(mean(Gr*Gr))}
		if(m >1){shat2 = sqrt(apply((Gr*Gr),1,mean))}
		ra2 = Gr/matrix(rep(shat2,n.sim),ncol=n.sim)
		rs2 = apply(abs(ra2),2,max)
		cp2 = quantile(rs2,probs=alpha)
		sigma2 = shat2/sqrt(n.sam*(hh^{dx}))
		uci.r[,,i] = cbind((Qy.adj - cp2*sigma2),(Qy.adj + cp2*sigma2))

		# point estimates
		Qd[,i] = Qy
		Qd.adj[,i] = Qy.adj
		# sigma
		sig[,i] = sigma; sig.r[,i] = sigma2
	}
	return(list(qte = Qd, qte.r = Qd.adj, uband = uci, uband.r = uci.r, s = sig, s.r = sig.r))	
}

plm.cv.app <- function(y, x, z, dz, x0, val, xl, order, bdy){
	# cv bandwidth for the partially linear model
	# use it for the applicaiton
	# designed to handle a large sample
	# x is the running variable, taking discrete values
	# bdy=1 yields the boundary point cv, bdy=0 yields the interior point cv
	x.u <- sort(unique(x))
	wdt <- quantile(abs(x-x0),probs=xl)	# use the closest (100*xl)% observations from x0
	x.m <- x.u[(abs(x.u-x0) < wdt) & x.u!=x0]
	if(dz!=0){
		z <- as.matrix(z)
		if(order==1){sel = (2+1):(2+dz)}
		if(order==2){sel = (3+1):(3+dz)}
	}
	cri <- array(0,c(length(val),1))
	for (i in 1:length(val)){
		h.tau <- val[i]
		cri.h <- NULL
		for (j in 1:length(x.m)){
			xe <- x.m[j]
			if(bdy==1){
				if(xe>=x0){sgn <-((x.u > x0)&(x.u > xe)&(x.u <= xe+h.tau))}
				if(xe< x0){sgn <-((x.u < x0)&(x.u < xe)&(x.u >= xe-h.tau))}
			}
			if(bdy==0){
				if(xe>=x0){sgn <-((x.u > x0)&(x.u!=xe)&(x.u <= xe+h.tau)&(x.u >= xe-h.tau))}
				if(xe< x0){sgn <-((x.u < x0)&(x.u!=xe)&(x.u <= xe+h.tau)&(x.u >= xe-h.tau))}
			}
			index <- x %in% x.u[sgn]
			xx <- x[index] - xe
			yy <- y[index]
			ww <- depa(xx/val[i])
			if(order==1){ # local linear regression
				if(dz==0){xs <- xx}
				if(dz!=0){xs <- cbind(xx,z[index,],(xx*z[index,]))}
			}
			if(order==2){ # local quadratic regression
				if(dz==0){xs <- cbind(xx,(xx^2))}
				if(dz!=0){xs <- cbind(xx,(xx^2),z[index,],(xx*z[index,]),((xx^2)*z[index,]))}
			}
			coe <- rq(yy ~ xs, method="fn", tau = 0.5, w = ww)$coef
			index2 <- (x==xe)
			if(dz==0){Qy <- coe[1]}
			if(dz==1) {Qy <- coe[1] + coe[sel]*z[index2,]}
			if(dz >1) {Qy <- coe[1] + (z[index2,] %*% coe[sel])}	
			cri.h <- c(cri.h,sum(abs(y[index2]-Qy)))
        }
	cri[i] <- mean(cri.h)
	}
	return(list(h.cv = val[which.min(cri)], cand = cbind(val,cri)))
}

#############################
## 3. Miscellaneous functions

poly.quad <- function(xx){
	# make quadratic and cross terms
	xx = as.matrix(xx)
	p = ncol(xx)
	xx2 = xx*xx		# quadratic terms
	if(p==1){zz = cbind(xx,xx2)}
	if(p>1){
		xx12 = NULL
		for(i in 1:(p-1)){	# cross terms
			xx12 = cbind(xx12,(xx[,i]*xx[,(i+1):p]))
		}
		zz = cbind(xx,xx2,xx12)
	}
	return(zz)
}

matl <- function(A,B,d){
# matrix multiplication
# A and B are two input matrices and d is an input vector
	B = as.matrix(B)
	s = 0
	for(i in 1:nrow(A)){
		s = s + d[i]*(A[i,] %*% t(B[i,]))
	}
	return(s)
}

depa <- function(xx,loc=0,scale=1){
# Epanechnikov kernel
	nx=(xx-loc)/scale
	return((scale^{-1})*(3/4)*(1-nx^2)*(abs(nx)<1))
}

logis <- function(x1,x2,b1,b2,scale=1){
# logistic function
	xb <- b1*x1+b2*x2
	return(scale/(1+exp(-xb)))
}

Q.true <- function(model,x0,z0,beta0,taus,x0.case=NULL){
	# true values of conditional quantiles (for simulation)
	if(model==1){gg <- 0.5 + 2*x0[1] + sin(2*pi*x0[1]-0.5)+x0[2]*qnorm(taus)}
	if(model==2) {
		rb1 = qnorm(taus); rb2 = qunif(taus)
		gg =  log(x0[1]*x0[2]) + logis(x0[1],x0[2],rb1,rb2,1) + x0[2]*rb1
		}
	if(model==3){
		if(x0.case %in% c(1,2,3)){gg <- 0.5+x0+(x0^2)+sin(pi*x0-1)+(x0+1.25)*qnorm(taus)}
		if(x0.case==4){gg <- rep(0,length(taus))}			
	}
	if(model%in%c(1,2)){zbeta = taus*z0[1] + sqrt(.2+taus)*z0[2]}
	if(model==3){zbeta = rep(beta0,(length(z0)/2)) %*% z0}
	tQ = gg + as.numeric(zbeta)
	if(model %in% c(1,2)) {return(list(trueQ = tQ, trueg = gg))}
	if(model==3 & (x0.case %in% c(1,2,3))) {return(list(trueQ = tQ, trueg = gg))}
	if(model==3 & (x0.case==4)) {return(list(trueQ = gg, trueg = gg))}	
}

########################################
## 4. Parallel computation, using Rmpi package

# This is a wrap-up function for the Step 1 of the global model
leave.one <- function(y,x,dn,dx,dz,tt,hh){
	require(quantreg)
	slave_num <- mpi.comm.rank()
	index = seq(slave_num,length(y),by=dn)
	ns = length(index)
	Be <- array(0,c(ns,length(tt),dz))
	for(j in 1:ns){
		js = index[j]
		Be[j,,] <- qrp.fir(y[-js],x[-js,],dx,dz,x0=x[js,1:dx],taus=tt,h.tau=hh)$est.beta
	}
	return(Be)
}


