## "Inference on Conditional Quantile Processes in Partially Linear Models with Applications to the Impact of Unemployment Benefits" 
## by Zhongjun Qu, Jungmo Yoon, and Pierre Perron
## August 2021
## This script replicates simulation exercises in the paper

rm(list=ls())
source("qte_rdd_cov.R")

n = 500			# sample size. try 500, 1000
model = 3		# choose 1,2,3. dx=2 when model=1,2 and dx=1 when model=3
if(model %in% c(1,2)){dx = 2}	# dx is the number of variables in the nonparametric part "g(x,tau)"
if(model==3){dx = 1}
dz = 2			# the number of variables in the linear part "z*beta(tau)"
x0.case = 3		# If dx=1, choose 1,2,3,4. x0.case=4 means a RD setup. If dx=2, choose 1,2,3. 
L = 500			# number of simulation repetitions. try L=500 or 1000

run.first = 1	# 1 for the global partially linear model, 0 for the local model
h.option = 1	# bandwidth in Step 1 of the global model. If 1, use h_cv, if 2, use h_opt
run.score = 1	# if 1, calculate the Res band (in addition to Asy band)

if(dx==1){xeval = c(-0.5,-0.3,0.0,0.0); x0 = xeval[x0.case]}
if(dx >1){xeval = rbind(c(0.5,0.5),c(0.5,0.75),c(0.9,0.9)); x0 = xeval[x0.case,]}
if(dx==1){beta0 = c(0.8,-0.2); z0 = rep(0.6,dz)}
if(dx >1){beta0 = c(0.5,0.5); z0 = rep(0.5,dz)}
if(x0.case!=4){rdd <- 0}
if(x0.case==4){rdd <- 1}
if(rdd==1){n <- 2*n}	# for RDD, the sample size is n for each side of the cutoff

alpha = c(0.9,0.95)			# set alpha=0.9 to get a 90% uniform CI
tt = seq(0.2,0.8,by=0.05)	# quantile levels to be estimated
tt.ext = c(0.25,0.5)*tt[1]	# extend quantile levels the for conditional density estimation
tt.exp = sort(c(tt.ext,tt,(1-tt.ext)))
ind = tt.exp %in% tt
tm = length(tt)
tm2 = length(tt.exp)

A <- array(0,c(L,tm,2))		# conditional quantiles Q.hat
B <- array(0,c(L,tm,dz))	# beta.hat
C <- array(0,c(L,tm))		# bias estimate
DH <- array(0,c(L,2))		# bandwidths at the median (cv,opt)
Wc <- array(0,c(L,tm,2,length(alpha)))	# conventional Wald band
Wc2 <- Wc; Wc3 <- Wc
Wr <- Wc						# robust Wald band
Sc <- array(0,c(L,tm,2,length(alpha)))	# conventional Score band
Sc2 <- Sc; Sc3 <- Sc
Sr <- Sc						# robust Score band
ind.sc <- array(1,c(L,1))		# indicator for the Score band (1 for success, 0 for failure)

for(l in 1:L){ # beginning of the simulation repetitions

# 1. generate data
	if(dx==2){	# two dimensional x
		px1 = rnorm(n); px2 = rnorm(n)
		v1 = rnorm(n); v2 = rnorm(n)
		wi = 0.24
		pz1 = wi*px1 + (1-wi)*v1
		pz2 = wi*px2 + (1-wi)*v2
		x1 = pnorm(px1); x2 = pnorm(px2)
		z1 = pnorm(pz1); z2 = pnorm(pz2)
		x  = cbind(x1,x2,z1,z2)
		rank  = runif(n)
		zbeta = (rank)*z1 + sqrt(.2+rank)*z2
	if(model==1){
		y = 0.5 + 2*x1 + sin(2*pi*x1-0.5) + x2*qnorm(rank) + zbeta
		}
	if(model==2){
		rb1 = qnorm(rank); rb2 = qunif(rank)
		y =  log(x1*x2) + logis(x1,x2,rb1,rb2,1) + x2*rb1 + zbeta}
	}
	if(dx==1){	# one dimensional x
		zc = array(0,c(n,dz))
		for(j in 1:dz) {zc[,j] = runif(n)}
		zbeta = zc %*% rep(beta0,(dz/2))	
		rank = runif(n)
	if(model==3 & (x0.case %in% c(1,2,3))){
		x1 = runif(n,min=-1,max=0)
		y = 0.5 + x1 + (x1^2) + sin(pi*x1-1) + (x1+1.25)*qnorm(rank) + zbeta
	}
	if(model==3 & x0.case==4){
		x1 = c(runif((n/2),min=-1,max=0),runif((n/2),min=0,max=1))	
		y = 0.5 + x1 + (x1^2) + sin(pi*x1-1) + (x1+1.25)*qnorm(rank) + zbeta
	}
	x = cbind(x1,zc)
	}
# 2. calculate bandwidths (CV and/or Optimal bandwidth)
bn <- nrq.bandwidth(y,x,dx,dz,x0,z0,rdd,step1=run.first,bdy=1,order=2,cv=1,hp=0.5)
	if(h.option==1 & rdd==0){h.med = bn$h.cv; h.med2 = bn$h.opt}
	if(h.option==2 & rdd==0){h.med = bn$h.opt; h.med2 = bn$h.opt}
	if(h.option==1 & rdd==1){h.med = bn$h.cv.m; h.med2 = bn$h.opt.m}
	if(h.option==2 & rdd==1){h.med = bn$h.opt.m; h.med2 = bn$h.opt.m}

# 3. Conditional quantile estimates and uniform bands
aa <- nrq(y,x,dx,dz,x0,z0,tau=tt,h.med,h.med2,rdd=rdd,step1=run.first,se=0)
ba <- nrq.band(y,x,dx,dz,x0,z0,tau=tt,h.med,h.med2,alpha,n.sim=1000,rdd=rdd,step1=run.first,res=run.score)

# 4. Save outcomes
# 4.1. point estimate, the bias estimate, and the bandwidth
A[l,,1] <- aa$Q.est.cor		# bias adjusted estimate
A[l,,2] <- aa$Q.est			# bias un-adjusted estimate
if(rdd==0){B[l,,] <- aa$beta.est}
if(rdd==1){B[l,,] <- aa$beta.est[1:dz,]}
C[l,] <- aa$bias.est
if(rdd==0){DH[l,] <- c(bn$h.cv,bn$h.opt)}
if(rdd==1){DH[l,] <- c(bn$h.cv.m,bn$h.opt.m)}

# 4.2. save Asy bands
Wc[l,,,] <- ba$uband		# no bias correction
Wr[l,,,] <- ba$uband.robust		# robust band
Wc2[l,,,1] <- ba$uband[,,1] - (t(rep(1,2)) %x% aa$bias.est)		# bias correction in point estimate
Wc2[l,,,2] <- ba$uband[,,2] - (t(rep(1,2)) %x% aa$bias.est)		
Wc3[l,,2,1] <- ba$uband[,2,1] - aa$bias.est*(aa$bias.est<=0)	# 'Wald M'
Wc3[l,,1,1] <- ba$uband[,1,1] - aa$bias.est*(aa$bias.est>=0)
Wc3[l,,2,2] <- ba$uband[,2,2] - aa$bias.est*(aa$bias.est<=0)
Wc3[l,,1,2] <- ba$uband[,1,2] - aa$bias.est*(aa$bias.est>=0)
# 4.3. save Res bands
if(run.score==1){
	Sc[l,,,] <- ba$uband.R		# no bias correction
	Sr[l,,,] <- ba$uband.robust.R	# robust
	Sc2[l,,,1] <- ba$uband.R[,,1] - (t(rep(1,2)) %x% aa$bias.est)
	Sc2[l,,,2] <- ba$uband.R[,,2] - (t(rep(1,2)) %x% aa$bias.est)
	Sc3[l,,2,1] <- ba$uband.R[,2,1] - aa$bias.est*(aa$bias.est<=0)	# 'Score M'
	Sc3[l,,1,1] <- ba$uband.R[,1,1] - aa$bias.est*(aa$bias.est>=0)
	Sc3[l,,2,2] <- ba$uband.R[,2,2] - aa$bias.est*(aa$bias.est<=0)
	Sc3[l,,1,2] <- ba$uband.R[,1,2] - aa$bias.est*(aa$bias.est>=0)
	ind.sc[l] <- ba$res.sc
}
print("number of iterations is "); print(l)
} # end of the simulation repetitions

# 5. Performance measures
# 5.1. beta.hat
Bias <- array(0,c(tm,dz))
Rmse <- array(0,c(tm,dz))
	#tbeta1 = tt
	#tbeta2 = sqrt(0.2+tt)
for(k in 1:tm){
	Bd = B[,k,] - rep(1,L) %o% rep(beta0,(dz/2))
	Bias[k,] <- apply(Bd,2,mean)
	Rmse[k,] <- sqrt(apply(Bd,2,crossprod)/L)
}

# 5.2. Q.hat and Bias estimates
Qtrue <- Q.true(model,x0,z0,beta0,taus=tt,x0.case)$trueQ
d <- A[,,1] - t(Qtrue) %x% rep(1,L)		# Q.hat - Q - Bias
d2 <- A[,,2] - t(Qtrue) %x% rep(1,L)		# Q.hat - Q
Bias2 <- cbind(apply(d,2,mean),apply(d2,2,mean),apply(C,2,mean))		# 'C' is the bias estimate
sd2 <- cbind(apply(d,2,sd),apply(d2,2,sd),apply(C,2,sd))
Rmse2 <- cbind(sqrt(apply(d,2,crossprod)/L),sqrt(apply(d2,2,crossprod)/L),sqrt(apply(C,2,crossprod)/L))

# 5.3. Coverage rates
coverage = array(0,c(8,length(alpha)))
width.w = array(0,c(tm,4,length(alpha)))
width.s = width.w
L2 = sum(ind.sc)
for(ii in 1:length(alpha)){
c1 = (Wr[,,1,ii] <= t(Qtrue) %x% rep(1,L)) & (Wr[,,2,ii] >= t(Qtrue) %x% rep(1,L))
c2 = (Wc[,,1,ii] <= t(Qtrue) %x% rep(1,L)) & (Wc[,,2,ii] >= t(Qtrue) %x% rep(1,L))
c3 = (Wc2[,,1,ii] <= t(Qtrue) %x% rep(1,L)) & (Wc2[,,2,ii] >= t(Qtrue) %x% rep(1,L))
c4 = (Wc3[,,1,ii] <= t(Qtrue) %x% rep(1,L)) & (Wc3[,,2,ii] >= t(Qtrue) %x% rep(1,L))
c5 = (Sr[(ind.sc==1),,1,ii] <= t(Qtrue) %x% rep(1,L2)) & (Sr[(ind.sc==1),,2,ii] >= t(Qtrue) %x% rep(1,L2))
c6 = (Sc[(ind.sc==1),,1,ii] <= t(Qtrue) %x% rep(1,L2)) & (Sc[(ind.sc==1),,2,ii] >= t(Qtrue) %x% rep(1,L2))
c7 = (Sc2[(ind.sc==1),,1,ii] <= t(Qtrue) %x% rep(1,L2)) & (Sc2[(ind.sc==1),,2,ii] >= t(Qtrue) %x% rep(1,L2))
c8 = (Sc3[(ind.sc==1),,1,ii] <= t(Qtrue) %x% rep(1,L2)) & (Sc3[(ind.sc==1),,2,ii] >= t(Qtrue) %x% rep(1,L2))
coverage[,ii] = c(mean(apply(c1,1,min)),mean(apply(c2,1,min)),mean(apply(c3,1,min)),mean(apply(c4,1,min)),mean(apply(c5,1,min)),mean(apply(c6,1,min)),mean(apply(c7,1,min)),mean(apply(c8,1,min)))

# 5.4. Width of confidence bands
w1  = apply((Wr[,,2,ii] - Wr[,,1,ii]),2,mean)
w2  = apply((Wc[,,2,ii] - Wc[,,1,ii]),2,mean)
w5  = apply((Wc3[,,2,ii] - Wc3[,,1,ii]),2,mean)
w12 = w1/w2
width.w[,,ii] = cbind(w1,w2,w5,w12)
w3  = apply((Sr[(ind.sc==1),,2,ii] - Sr[(ind.sc==1),,1,ii]),2,mean)
w4  = apply((Sc[(ind.sc==1),,2,ii] - Sc[(ind.sc==1),,1,ii]),2,mean)
w6  = apply((Sc3[(ind.sc==1),,2,ii] - Sc3[(ind.sc==1),,1,ii]),2,mean)
w34 = w3/w4
width.s[,,ii] = cbind(w3,w4,w6,w34)
}

# 6. save outcomes
save(A,B,C,DH,Wc,Wc2,Wc3,Wr,Sc,Sc2,Sc3,Sr,Bias,Rmse,Bias2,Rmse2,sd2,coverage,width.w,width.s,tt,x0,z0,beta0,n,alpha,h.option,L,model,ind.sc,L2,file=paste("rep_sim_","Aug",18,"_2021","_dx",dx,"_dz",dz,"_n",n,"_fir",run.first,"_m",model,"_x",x0.case,".rda",sep=""))
