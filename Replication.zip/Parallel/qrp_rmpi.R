## "Inference on Conditional Quantile Processes in Partially Linear Models with Applications to the Impact of Unemployment Benefits" 
## by Zhongjun Qu, Jungmo Yoon, and Pierre Perron
## August 2021
## Estimating the global model, using a R package 'Rmpi'
## To run this script, see 'run_rmpi.txt'

library("Rmpi")
require(quantreg)
source("qrp_rmpi_fn.R")

print( mpi.universe.size() )
ns <- mpi.universe.size() - 1
mpi.spawn.Rslaves( nslaves = ns )

# In case R exits unexpectedly, have it automatically clean up
# resources taken up by Rmpi (slaves, memory, etc...)
.Last <- function(){
  if ( is.loaded("mpi_initialize")){
     if (mpi.comm.size(1) > 0){
            print("Please use mpi.close.Rslaves() to close slaves.")
            mpi.close.Rslaves()
     }
     print("Please use mpi.quit() to quit R")
     .Call("mpi_finalize")
   }
}

# Beginning of the R code

date = 25
num <- c(5000,10000,20000,50000,100000,200000) # sample sizes to try
#num <- 1000000		# Careful! one million observation takes time
model = 1
dz = 2; dx=2
x0 = c(0.5,0.5); z0 = rep(0.6,dz)
tt = seq(0.2,0.8,by=0.05)
tm = length(tt)
n.case = length(num)

CT = array(0,c(n.case,1))
ctime = NULL

A <- array(0,c(n.case,tm,2))	# conditional quantiles Q.hat
B <- array(0,c(n.case,tm,dz))	# beta.hat
B2 <- array(0,c(n.case,tm,dz))	# beta.hat - true beta0
C <- array(0,c(n.case,tm))		# bias estimate in Q.hat
for(k in 1:n.case){
	
	n <- num[k]		# sample size
	start_time <- Sys.time()	# recording starting time

if(model %in% c(1,2)){	# two dimensional x
	px1 = rnorm(n); px2 = rnorm(n)
	v1 = rnorm(n); v2 = rnorm(n)
	wi = 0.24		# make correlation 0.3
	pz1 = wi*px1 + (1-wi)*v1
	pz2 = wi*px2 + (1-wi)*v2
	x1 = pnorm(px1); x2 = pnorm(px2)
	z1 = pnorm(pz1); z2 = pnorm(pz2)
	x  = cbind(x1,x2,z1,z2)
	rank  = runif(n)
	zbeta = (rank)*z1 + sqrt(.2+rank)*z2
	if(model==1){y = 0.5 + 2*x1 + sin(2*pi*x1-0.5) + x2*qnorm(rank) + zbeta}
	if(model==2){
		rb1 = qnorm(rank); rb2 = qunif(rank)
		y =  log(x1*x2) + logis(x1,x2,rb1,rb2,1) + x2*rb1 + zbeta}
}
h.med = 1.213*(n^{-1/5})	# bandwidth depends on 'n'. When n=500, h.med=0.35 
hh = rep(h.med,length(tt))
hh2 = h.med*((2*tt*(1-tt)/(pi*dnorm(qnorm(tt))^{2}))^{1/(4+dx)})	

# Step 1
# pass functions to slaves
mpi.bcast.Robj2slave(leave.one)
mpi.bcast.Robj2slave(qrp.fir)
mpi.bcast.Robj2slave(poly.quad)
mpi.bcast.Robj2slave(depa)
# pass the job to slaves 
outcome <- mpi.remote.exec(cmd = leave.one, y,x,ns,dx,dz,tt,hh)
# collect outcomes from slaves
beta.hat <- array(0,c(dz,tm))
for(j in 1:tm){
	Be <- NULL
	for(i in 1:ns){
		Be <- rbind(Be,outcome[[i]][,j,])
	}
	beta.hat[,j] <- apply(Be,2,mean)
}

# Step 2
s2 = qrp.sec(y,x,dx,dz,x0,taus=tt,h.tau=hh2,beta=beta.hat,get.se=0)
g.hat = s2$est.a0
bb = qrp.bias(y,x,dx,dz,x0,taus=tt,h.tau=hh2,h.tau2=hh2,beta=beta.hat,get.se=0)
bias.est = bb$bias
Qhat = g.hat + t(beta.hat) %*% z0

# Save outcomes 
A[k,,1] <- Qhat - bias.est	# bias adjusted estimate
A[k,,2] <- Qhat				# bias un-adjusted estimate
B[k,,] <- t(beta.hat)
B2[k,,] <- t(beta.hat) - cbind(tt,sqrt(0.2+tt))
C[k,] <- bias.est

# Save computing time
end_time <- Sys.time()	# record ending time
comp.time <- end_time - start_time
CT[k] <- comp.time
ctime <- rbind(ctime,c(start_time,end_time))
}	# end of the loop for different sample sizes

save(num,ctime,CT,A,B,B2,C,tt,file=paste("mpi","_July",date,"_2021","_node",ns,".rda",sep=""))

# Tell all slaves to close down, and exit the program
mpi.close.Rslaves()
mpi.quit()
